const fs = require('fs');
const path = require('path');

const categories = [
  'Web Browsers',
  'Messaging & Communication',
  'Media & Streaming',
  'Image & Design',
  'Documents & PDFs',
  'Compression & File Management',
  'Security & Password Managers',
  'Cloud Storage & Sync',
  'Gaming & Game Dev',
  'Developer Tools',
  'Networking & Remote Access',
  'System Utilities',
  'Virtualization & Containers',
  '3D, CAD & 3D Printing',
  'Education & Accessibility',
  'Runtimes & Dependencies'
];

const allApps = [
  // 1. WEB BROWSERS (10)
  {
    id: 'google-chrome',
    name: 'Google Chrome',
    category: 'Web Browsers',
    description: 'Fast, secure, and customizable web browser built by Google.',
    publisher: 'Google LLC',
    website: 'https://www.google.com/chrome/',
    downloadPage: 'https://www.google.com/chrome/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Google.Chrome' },
      macos: { manager: 'brew', packageId: 'google-chrome', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.google.Chrome' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Google.Chrome' } },
    tags: ['browser', 'google', 'web'],
    featured: true
  },
  {
    id: 'mozilla-firefox',
    name: 'Mozilla Firefox',
    category: 'Web Browsers',
    description: 'Free, open-source browser committed to personal privacy and standards.',
    publisher: 'Mozilla Foundation',
    website: 'https://www.mozilla.org/firefox/',
    downloadPage: 'https://www.mozilla.org/firefox/new/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Mozilla.Firefox' },
      macos: { manager: 'brew', packageId: 'firefox', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.mozilla.firefox' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Mozilla.Firefox' } },
    tags: ['browser', 'mozilla', 'open-source', 'privacy'],
    featured: true
  },
  {
    id: 'microsoft-edge',
    name: 'Microsoft Edge',
    category: 'Web Browsers',
    description: 'High-performance Chromium-based browser with Copilot integration.',
    publisher: 'Microsoft Corporation',
    website: 'https://www.microsoft.com/edge',
    downloadPage: 'https://www.microsoft.com/edge/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.Edge' },
      macos: { manager: 'brew', packageId: 'microsoft-edge', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.microsoft.Edge' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.Edge' } },
    tags: ['browser', 'microsoft', 'chromium']
  },
  {
    id: 'brave-browser',
    name: 'Brave Browser',
    category: 'Web Browsers',
    description: 'Privacy-first browser blocking ads, trackers, and fingerprinting automatically.',
    publisher: 'Brave Software',
    website: 'https://brave.com/',
    downloadPage: 'https://brave.com/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Brave.Brave' },
      macos: { manager: 'brew', packageId: 'brave-browser', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.brave.Browser' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Brave.Brave' } },
    tags: ['browser', 'privacy', 'adblock', 'crypto'],
    featured: true
  },
  {
    id: 'opera',
    name: 'Opera Browser',
    category: 'Web Browsers',
    description: 'Modern browser with built-in free VPN, ad blocker, and messengers.',
    publisher: 'Opera Norway',
    website: 'https://www.opera.com/',
    downloadPage: 'https://www.opera.com/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Opera.Opera' },
      macos: { manager: 'brew', packageId: 'opera', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.opera.Opera' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Opera.Opera' } },
    tags: ['browser', 'vpn', 'adblock']
  },
  {
    id: 'opera-gx',
    name: 'Opera GX',
    category: 'Web Browsers',
    description: 'Special edition browser tailored specifically for gamers with hardware limiters.',
    publisher: 'Opera Norway',
    website: 'https://www.opera.com/gx',
    downloadPage: 'https://www.opera.com/gx',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Opera.OperaGX' },
      macos: { manager: 'brew', packageId: 'opera-gx', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Opera.OperaGX' } },
    tags: ['browser', 'gaming', 'rgb']
  },
  {
    id: 'vivaldi',
    name: 'Vivaldi Browser',
    category: 'Web Browsers',
    description: 'Feature-rich power-user browser with deep customizability and tab management.',
    publisher: 'Vivaldi Technologies',
    website: 'https://vivaldi.com/',
    downloadPage: 'https://vivaldi.com/download/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'VivaldiTechnologies.Vivaldi' },
      macos: { manager: 'brew', packageId: 'vivaldi', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.vivaldi.Vivaldi' }
    },
    detection: { windows: { type: 'winget', checkValue: 'VivaldiTechnologies.Vivaldi' } },
    tags: ['browser', 'power-user', 'customizable']
  },
  {
    id: 'chromium',
    name: 'Chromium',
    category: 'Web Browsers',
    description: 'Pure open-source browser project that powers Google Chrome and Edge.',
    publisher: 'The Chromium Project',
    website: 'https://www.chromium.org/',
    downloadPage: 'https://download-chromium.appspot.com/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Hibbiki.Chromium' },
      macos: { manager: 'brew', packageId: 'eloston-chromium', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.chromium.Chromium' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Hibbiki.Chromium' } },
    tags: ['browser', 'open-source', 'engine']
  },
  {
    id: 'tor-browser',
    name: 'Tor Browser',
    category: 'Web Browsers',
    description: 'Defend yourself against tracking, surveillance, and censorship with onion routing.',
    publisher: 'The Tor Project',
    website: 'https://www.torproject.org/',
    downloadPage: 'https://www.torproject.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'TorProject.TorBrowser' },
      macos: { manager: 'brew', packageId: 'tor-browser', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.github.micahflee.torbrowser-launcher' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TorProject.TorBrowser' } },
    tags: ['browser', 'tor', 'privacy', 'anonymity']
  },
  {
    id: 'librewolf',
    name: 'LibreWolf',
    category: 'Web Browsers',
    description: 'A custom, independent version of Firefox focused on privacy and telemetry removal.',
    publisher: 'LibreWolf Community',
    website: 'https://librewolf.net/',
    downloadPage: 'https://librewolf.net/installation/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'LibreWolf.LibreWolf' },
      macos: { manager: 'brew', packageId: 'librewolf', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.gitlab.librewolf-community' }
    },
    detection: { windows: { type: 'winget', checkValue: 'LibreWolf.LibreWolf' } },
    tags: ['browser', 'hardened', 'firefox', 'privacy']
  },

  // 2. MESSAGING & COMMUNICATION (14)
  {
    id: 'discord',
    name: 'Discord',
    category: 'Messaging & Communication',
    description: 'All-in-one voice, video, and text communication platform for communities.',
    publisher: 'Discord Inc.',
    website: 'https://discord.com/',
    downloadPage: 'https://discord.com/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Discord.Discord' },
      macos: { manager: 'brew', packageId: 'discord', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.discordapp.Discord' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Discord.Discord' } },
    tags: ['chat', 'voice', 'gaming', 'community'],
    featured: true
  },
  {
    id: 'zoom',
    name: 'Zoom Workplace',
    category: 'Messaging & Communication',
    description: 'Enterprise video communication with real-time messaging and content sharing.',
    publisher: 'Zoom Video Communications',
    website: 'https://zoom.us/',
    downloadPage: 'https://zoom.us/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Zoom.Zoom' },
      macos: { manager: 'brew', packageId: 'zoom', cask: true },
      linux: { manager: 'flatpak', packageId: 'us.zoom.Zoom' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Zoom.Zoom' } },
    tags: ['video', 'meetings', 'conference']
  },
  {
    id: 'microsoft-teams',
    name: 'Microsoft Teams',
    category: 'Messaging & Communication',
    description: 'Workplace chat, video meetings, file storage, and app integration.',
    publisher: 'Microsoft Corporation',
    website: 'https://www.microsoft.com/teams',
    downloadPage: 'https://www.microsoft.com/microsoft-teams/download-app',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.Teams' },
      macos: { manager: 'brew', packageId: 'microsoft-teams', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.Teams' } },
    tags: ['team', 'chat', 'office365']
  },
  {
    id: 'slack',
    name: 'Slack',
    category: 'Messaging & Communication',
    description: 'Collaboration hub bringing the right people, information, and tools together.',
    publisher: 'Slack Technologies',
    website: 'https://slack.com/',
    downloadPage: 'https://slack.com/downloads',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'SlackTechnologies.Slack' },
      macos: { manager: 'brew', packageId: 'slack', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.slack.Slack' }
    },
    detection: { windows: { type: 'winget', checkValue: 'SlackTechnologies.Slack' } },
    tags: ['work', 'collaboration', 'channels'],
    featured: true
  },
  {
    id: 'telegram',
    name: 'Telegram Desktop',
    category: 'Messaging & Communication',
    description: 'Fast and secure desktop messaging app synced seamlessly across devices.',
    publisher: 'Telegram FZ-LLC',
    website: 'https://desktop.telegram.org/',
    downloadPage: 'https://desktop.telegram.org/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Telegram.TelegramDesktop' },
      macos: { manager: 'brew', packageId: 'telegram', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.telegram.desktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Telegram.TelegramDesktop' } },
    tags: ['chat', 'cloud', 'fast', 'messenger']
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    category: 'Messaging & Communication',
    description: 'Official WhatsApp native desktop application for chats and calls.',
    publisher: 'Meta Platforms, Inc.',
    website: 'https://www.whatsapp.com/',
    downloadPage: 'https://www.whatsapp.com/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'WhatsApp.WhatsApp' },
      macos: { manager: 'brew', packageId: 'whatsapp', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'WhatsApp.WhatsApp' } },
    tags: ['messaging', 'whatsapp', 'mobile']
  },
  {
    id: 'signal',
    name: 'Signal Messenger',
    category: 'Messaging & Communication',
    description: 'Gold-standard open source end-to-end encrypted messaging and calling.',
    publisher: 'Signal Messenger LLC',
    website: 'https://signal.org/',
    downloadPage: 'https://signal.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'OpenWhisperSystems.Signal' },
      macos: { manager: 'brew', packageId: 'signal', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.signal.Signal' }
    },
    detection: { windows: { type: 'winget', checkValue: 'OpenWhisperSystems.Signal' } },
    tags: ['privacy', 'encryption', 'signal'],
    featured: true
  },
  {
    id: 'element',
    name: 'Element Desktop',
    category: 'Messaging & Communication',
    description: 'Decentralized Matrix communication client for secure, distributed messaging.',
    publisher: 'Element (New Vector Ltd)',
    website: 'https://element.io/',
    downloadPage: 'https://element.io/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Element.Element' },
      macos: { manager: 'brew', packageId: 'element', cask: true },
      linux: { manager: 'flatpak', packageId: 'im.riot.Riot' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Element.Element' } },
    tags: ['matrix', 'decentralized', 'open-source']
  },
  {
    id: 'thunderbird',
    name: 'Mozilla Thunderbird',
    category: 'Messaging & Communication',
    description: 'Powerful, privacy-respecting email, calendar, and address book client.',
    publisher: 'Mozilla Foundation',
    website: 'https://www.thunderbird.net/',
    downloadPage: 'https://www.thunderbird.net/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Mozilla.Thunderbird' },
      macos: { manager: 'brew', packageId: 'thunderbird', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.mozilla.Thunderbird' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Mozilla.Thunderbird' } },
    tags: ['email', 'calendar', 'mozilla']
  },
  {
    id: 'pidgin',
    name: 'Pidgin',
    category: 'Messaging & Communication',
    description: 'Universal chat program which lets you log in to accounts on multiple networks.',
    publisher: 'Pidgin Developers',
    website: 'https://pidgin.im/',
    downloadPage: 'https://pidgin.im/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Pidgin.Pidgin' },
      linux: { manager: 'flatpak', packageId: 'im.pidgin.Pidgin' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Pidgin.Pidgin' } },
    tags: ['chat', 'xmpp', 'irc']
  },
  {
    id: 'mumble',
    name: 'Mumble',
    category: 'Messaging & Communication',
    description: 'Open source, low-latency, high quality voice chat for gamers.',
    publisher: 'The Mumble Team',
    website: 'https://www.mumble.info/',
    downloadPage: 'https://www.mumble.info/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Mumble.Mumble' },
      macos: { manager: 'brew', packageId: 'mumble', cask: true },
      linux: { manager: 'flatpak', packageId: 'info.mumble.Mumble' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Mumble.Mumble' } },
    tags: ['voice', 'gaming', 'low-latency']
  },
  {
    id: 'teamspeak',
    name: 'TeamSpeak Client',
    category: 'Messaging & Communication',
    description: 'Clear voice communication client with military-grade security and admin controls.',
    publisher: 'TeamSpeak Systems GmbH',
    website: 'https://www.teamspeak.com/',
    downloadPage: 'https://www.teamspeak.com/en/downloads/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'TeamSpeakSystems.TeamSpeakClient' },
      macos: { manager: 'brew', packageId: 'teamspeak-client', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.teamspeak.TeamSpeak3' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TeamSpeakSystems.TeamSpeakClient' } },
    tags: ['voice', 'gaming', 'teamspeak']
  },
  {
    id: 'webex',
    name: 'Cisco Webex',
    category: 'Messaging & Communication',
    description: 'Enterprise virtual meeting, team collaboration, and webinar solution.',
    publisher: 'Cisco Systems, Inc.',
    website: 'https://www.webex.com/',
    downloadPage: 'https://www.webex.com/downloads.html',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Cisco.Webex' },
      macos: { manager: 'brew', packageId: 'webex', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.cisco.Webex' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Cisco.Webex' } },
    tags: ['meetings', 'enterprise', 'video']
  },
  {
    id: 'session',
    name: 'Session',
    category: 'Messaging & Communication',
    description: 'End-to-end encrypted messenger with zero metadata footprint and onion routing.',
    publisher: 'Oxen Privacy Tech Foundation',
    website: 'https://getsession.org/',
    downloadPage: 'https://getsession.org/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Oxen.Session' },
      macos: { manager: 'brew', packageId: 'session', cask: true },
      linux: { manager: 'flatpak', packageId: 'network.loki.Session' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Oxen.Session' } },
    tags: ['privacy', 'anonymous', 'crypto']
  },

  // 3. MEDIA & STREAMING (18)
  {
    id: 'vlc',
    name: 'VLC Media Player',
    category: 'Media & Streaming',
    description: 'Universal, open-source media player that plays files, discs, and network streams.',
    publisher: 'VideoLAN',
    website: 'https://www.videolan.org/vlc/',
    downloadPage: 'https://www.videolan.org/vlc/download-windows.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'VideoLAN.VLC' },
      macos: { manager: 'brew', packageId: 'vlc', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.videolan.VLC' }
    },
    detection: { windows: { type: 'winget', checkValue: 'VideoLAN.VLC' } },
    tags: ['video', 'audio', 'player', 'codecs'],
    featured: true
  },
  {
    id: 'spotify',
    name: 'Spotify',
    category: 'Media & Streaming',
    description: 'Stream music, playlists, podcasts, and audiobooks on demand.',
    publisher: 'Spotify AB',
    website: 'https://www.spotify.com/',
    downloadPage: 'https://www.spotify.com/download/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Spotify.Spotify' },
      macos: { manager: 'brew', packageId: 'spotify', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.spotify.Client' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Spotify.Spotify' } },
    tags: ['music', 'audio', 'streaming'],
    featured: true
  },
  {
    id: 'obs-studio',
    name: 'OBS Studio',
    category: 'Media & Streaming',
    description: 'Free, open source video recording and live broadcasting suite.',
    publisher: 'OBS Project',
    website: 'https://obsproject.com/',
    downloadPage: 'https://obsproject.com/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'OBSProject.OBSStudio' },
      macos: { manager: 'brew', packageId: 'obs', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.obsproject.Studio' }
    },
    detection: { windows: { type: 'winget', checkValue: 'OBSProject.OBSStudio' } },
    tags: ['streaming', 'recording', 'twitch', 'youtube'],
    featured: true
  },
  {
    id: 'audacity',
    name: 'Audacity',
    category: 'Media & Streaming',
    description: 'Easy-to-use, multi-track audio editor and recorder.',
    publisher: 'Audacity Team',
    website: 'https://www.audacityteam.org/',
    downloadPage: 'https://www.audacityteam.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Audacity.Audacity' },
      macos: { manager: 'brew', packageId: 'audacity', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.audacityteam.Audacity' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Audacity.Audacity' } },
    tags: ['audio', 'editor', 'podcasting']
  },
  {
    id: 'handbrake',
    name: 'HandBrake',
    category: 'Media & Streaming',
    description: 'Versatile video transcoder converting videos into modern formats.',
    publisher: 'HandBrake Team',
    website: 'https://handbrake.fr/',
    downloadPage: 'https://handbrake.fr/downloads.php',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'HandBrake.HandBrake' },
      macos: { manager: 'brew', packageId: 'handbrake', cask: true },
      linux: { manager: 'flatpak', packageId: 'fr.handbrake.ghb' }
    },
    detection: { windows: { type: 'winget', checkValue: 'HandBrake.HandBrake' } },
    tags: ['video', 'encoding', 'converter']
  },
  {
    id: 'foobar2000',
    name: 'foobar2000',
    category: 'Media & Streaming',
    description: 'Advanced, lightweight audio player with endless UI and audio plugin capabilities.',
    publisher: 'Peter Pawlowski',
    website: 'https://www.foobar2000.org/',
    downloadPage: 'https://www.foobar2000.org/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'PeterPawlowski.foobar2000' },
      macos: { manager: 'brew', packageId: 'foobar2000', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'PeterPawlowski.foobar2000' } },
    tags: ['audio', 'flac', 'customizable']
  },
  {
    id: 'aimp',
    name: 'AIMP',
    category: 'Media & Streaming',
    description: 'Powerful Windows audio player with 32-bit audio processing and equalizer.',
    publisher: 'Artem Izmaylov',
    website: 'https://www.aimp.ru/',
    downloadPage: 'https://www.aimp.ru/?do=download',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'ArtemIzmaylov.AIMP' }
    },
    detection: { windows: { type: 'winget', checkValue: 'ArtemIzmaylov.AIMP' } },
    tags: ['music', 'player', 'radio']
  },
  {
    id: 'musicbee',
    name: 'MusicBee',
    category: 'Media & Streaming',
    description: 'Ultimate music manager for managing large music collections with ease.',
    publisher: 'Steven Mayall',
    website: 'https://getmusicbee.com/',
    downloadPage: 'https://getmusicbee.com/downloads/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'StevenMayall.MusicBee' }
    },
    detection: { windows: { type: 'winget', checkValue: 'StevenMayall.MusicBee' } },
    tags: ['music', 'library', 'tagging']
  },
  {
    id: 'mpv',
    name: 'mpv player',
    category: 'Media & Streaming',
    description: 'Streamlined, GPU-accelerated command-line and GUI media player.',
    publisher: 'mpv-player team',
    website: 'https://mpv.io/',
    downloadPage: 'https://mpv.io/installation/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'shinchiro.mpv' },
      macos: { manager: 'brew', packageId: 'mpv', cask: false },
      linux: { manager: 'flatpak', packageId: 'io.mpv.Mpv' }
    },
    detection: { windows: { type: 'winget', checkValue: 'shinchiro.mpv' } },
    tags: ['video', 'minimalist', 'gpu']
  },
  {
    id: 'kodi',
    name: 'Kodi',
    category: 'Media & Streaming',
    description: 'Open-source entertainment hub for movies, TV shows, and music.',
    publisher: 'XBMC Foundation',
    website: 'https://kodi.tv/',
    downloadPage: 'https://kodi.tv/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'XBMCFoundation.Kodi' },
      macos: { manager: 'brew', packageId: 'kodi', cask: true },
      linux: { manager: 'flatpak', packageId: 'tv.kodi.Kodi' }
    },
    detection: { windows: { type: 'winget', checkValue: 'XBMCFoundation.Kodi' } },
    tags: ['htpc', 'media-center', 'living-room']
  },
  {
    id: 'clementine',
    name: 'Clementine Music Player',
    category: 'Media & Streaming',
    description: 'Multiplatform music player and library organizer inspired by Amarok.',
    publisher: 'Clementine Developers',
    website: 'https://www.clementine-player.org/',
    downloadPage: 'https://www.clementine-player.org/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Clementine.Clementine' },
      macos: { manager: 'brew', packageId: 'clementine', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.clementine_player.Clementine' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Clementine.Clementine' } },
    tags: ['music', 'radio', 'organizer']
  },
  {
    id: 'strawberry',
    name: 'Strawberry Music Player',
    category: 'Media & Streaming',
    description: 'Audiophile music player for collectors with high-resolution audio support.',
    publisher: 'Jonas Kvinge',
    website: 'https://www.strawberrymusicplayer.org/',
    downloadPage: 'https://www.strawberrymusicplayer.org/#download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'StrawberryMusicPlayer.Strawberry' },
      macos: { manager: 'brew', packageId: 'strawberry', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.strawberrymusicplayer.strawberry' }
    },
    detection: { windows: { type: 'winget', checkValue: 'StrawberryMusicPlayer.Strawberry' } },
    tags: ['audiophile', 'lossless', 'flac']
  },
  {
    id: 'jellyfin-media-player',
    name: 'Jellyfin Media Player',
    category: 'Media & Streaming',
    description: 'Native desktop client for your personal Jellyfin media system.',
    publisher: 'Jellyfin Project',
    website: 'https://jellyfin.org/',
    downloadPage: 'https://jellyfin.org/downloads/clients/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Jellyfin.JellyfinMediaPlayer' },
      macos: { manager: 'brew', packageId: 'jellyfin-media-player', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.github.iwalton3.jellyfin-media-player' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Jellyfin.JellyfinMediaPlayer' } },
    tags: ['streaming', 'media-server', 'open-source']
  },
  {
    id: 'plex',
    name: 'Plex for Desktop',
    category: 'Media & Streaming',
    description: 'Plex client for direct hardware video playback on desktop computers.',
    publisher: 'Plex Inc.',
    website: 'https://www.plex.tv/',
    downloadPage: 'https://www.plex.tv/media-server-downloads/#plex-app',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Plex.Plex' },
      macos: { manager: 'brew', packageId: 'plex', cask: true },
      linux: { manager: 'flatpak', packageId: 'tv.plex.PlexDesktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Plex.Plex' } },
    tags: ['streaming', 'movies', 'series']
  },
  {
    id: 'itunes',
    name: 'Apple iTunes',
    category: 'Media & Streaming',
    description: 'Manage Apple media, music library, and iOS device backups on Windows.',
    publisher: 'Apple Inc.',
    website: 'https://www.apple.com/itunes/',
    downloadPage: 'https://www.apple.com/itunes/download/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Apple.iTunes' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Apple.iTunes' } },
    tags: ['apple', 'sync', 'ios']
  },
  {
    id: 'shotcut',
    name: 'Shotcut',
    category: 'Media & Streaming',
    description: 'Free, open source video editor supporting hundreds of audio and video formats.',
    publisher: 'Meltytech, LLC',
    website: 'https://shotcut.org/',
    downloadPage: 'https://shotcut.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Meltytech.Shotcut' },
      macos: { manager: 'brew', packageId: 'shotcut', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.shotcut.Shotcut' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Meltytech.Shotcut' } },
    tags: ['video', 'editor', '4k']
  },
  {
    id: 'kdenlive',
    name: 'Kdenlive',
    category: 'Media & Streaming',
    description: 'Professional non-linear video editing suite with multi-track timeline.',
    publisher: 'KDE Community',
    website: 'https://kdenlive.org/',
    downloadPage: 'https://kdenlive.org/en/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KDE.Kdenlive' },
      macos: { manager: 'brew', packageId: 'kdenlive', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.kde.kdenlive' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KDE.Kdenlive' } },
    tags: ['video', 'editing', 'kde']
  },
  {
    id: 'openshot',
    name: 'OpenShot Video Editor',
    category: 'Media & Streaming',
    description: 'Simple and intuitive open-source video editor for fast video cuts and titles.',
    publisher: 'OpenShot Studios, LLC',
    website: 'https://www.openshot.org/',
    downloadPage: 'https://www.openshot.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'OpenShot.OpenShotVideoEditor' },
      macos: { manager: 'brew', packageId: 'openshot-video-editor', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.openshot.OpenShot' }
    },
    detection: { windows: { type: 'winget', checkValue: 'OpenShot.OpenShotVideoEditor' } },
    tags: ['video', 'editing', 'beginner']
  },

  // 4. IMAGE & DESIGN (17)
  {
    id: 'gimp',
    name: 'GIMP',
    category: 'Image & Design',
    description: 'Cross-platform image editor for photo retouching, image composition and authoring.',
    publisher: 'GIMP Team',
    website: 'https://www.gimp.org/',
    downloadPage: 'https://www.gimp.org/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GIMP.GIMP' },
      macos: { manager: 'brew', packageId: 'gimp', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.gimp.GIMP' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GIMP.GIMP' } },
    tags: ['photo', 'editing', 'raster', 'open-source'],
    featured: true
  },
  {
    id: 'krita',
    name: 'Krita',
    category: 'Image & Design',
    description: 'Professional open-source painting program designed for concept artists and illustrators.',
    publisher: 'KDE / Krita Foundation',
    website: 'https://krita.org/',
    downloadPage: 'https://krita.org/en/download/krita-desktop/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KDE.Krita' },
      macos: { manager: 'brew', packageId: 'krita', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.kde.krita' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KDE.Krita' } },
    tags: ['painting', 'drawing', 'illustration', 'art'],
    featured: true
  },
  {
    id: 'inkscape',
    name: 'Inkscape',
    category: 'Image & Design',
    description: 'Professional vector graphics editor for creating SVG logos, illustrations, and art.',
    publisher: 'Inkscape Project',
    website: 'https://inkscape.org/',
    downloadPage: 'https://inkscape.org/release/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Inkscape.Inkscape' },
      macos: { manager: 'brew', packageId: 'inkscape', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.inkscape.Inkscape' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Inkscape.Inkscape' } },
    tags: ['vector', 'svg', 'illustration', 'design']
  },
  {
    id: 'blender',
    name: 'Blender',
    category: 'Image & Design',
    description: 'Comprehensive 3D creation suite: modeling, rigging, animation, simulation, rendering.',
    publisher: 'Blender Foundation',
    website: 'https://www.blender.org/',
    downloadPage: 'https://www.blender.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'BlenderFoundation.Blender' },
      macos: { manager: 'brew', packageId: 'blender', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.blender.Blender' }
    },
    detection: { windows: { type: 'winget', checkValue: 'BlenderFoundation.Blender' } },
    tags: ['3d', 'animation', 'rendering', 'vfx'],
    featured: true
  },
  {
    id: 'paint-net',
    name: 'Paint.NET',
    category: 'Image & Design',
    description: 'Fast image and photo editing software with layer support and special effects.',
    publisher: 'dotPDN LLC',
    website: 'https://www.getpaint.net/',
    downloadPage: 'https://www.getpaint.net/download.html',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'dotPDN.PaintDotNet' }
    },
    detection: { windows: { type: 'winget', checkValue: 'dotPDN.PaintDotNet' } },
    tags: ['image', 'editor', 'photo', 'layers']
  },
  {
    id: 'sharex',
    name: 'ShareX',
    category: 'Image & Design',
    description: 'Screen capture, file sharing, and productivity tool with rich annotation features.',
    publisher: 'ShareX Team',
    website: 'https://getsharex.com/',
    downloadPage: 'https://getsharex.com/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'ShareX.ShareX' }
    },
    detection: { windows: { type: 'winget', checkValue: 'ShareX.ShareX' } },
    tags: ['screenshot', 'screen-recorder', 'annotation'],
    featured: true
  },
  {
    id: 'greenshot',
    name: 'Greenshot',
    category: 'Image & Design',
    description: 'Lightweight screenshot tool for Windows with quick image annotation.',
    publisher: 'Greenshot Team',
    website: 'https://getgreenshot.org/',
    downloadPage: 'https://getgreenshot.org/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'Greenshot.Greenshot' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Greenshot.Greenshot' } },
    tags: ['screenshot', 'productivity', 'capture']
  },
  {
    id: 'flameshot',
    name: 'Flameshot',
    category: 'Image & Design',
    description: 'Powerful yet simple to use cross-platform screenshot software with on-screen editing.',
    publisher: 'Flameshot Team',
    website: 'https://flameshot.org/',
    downloadPage: 'https://flameshot.org/#download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Flameshot.Flameshot' },
      macos: { manager: 'brew', packageId: 'flameshot', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.flameshot.Flameshot' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Flameshot.Flameshot' } },
    tags: ['screenshot', 'annotation', 'cross-platform']
  },
  {
    id: 'darktable',
    name: 'darktable',
    category: 'Image & Design',
    description: 'Open source photography workflow application and non-destructive raw developer.',
    publisher: 'darktable developers',
    website: 'https://www.darktable.org/',
    downloadPage: 'https://www.darktable.org/install/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Darktable.Darktable' },
      macos: { manager: 'brew', packageId: 'darktable', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.darktable.Darktable' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Darktable.Darktable' } },
    tags: ['raw', 'photo', 'lightroom-alternative']
  },
  {
    id: 'rawtherapee',
    name: 'RawTherapee',
    category: 'Image & Design',
    description: 'Powerful cross-platform raw photo processing software utilizing 32-bit floating-point engine.',
    publisher: 'RawTherapee Team',
    website: 'https://rawtherapee.com/',
    downloadPage: 'https://rawtherapee.com/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RawTherapee.RawTherapee' },
      macos: { manager: 'brew', packageId: 'rawtherapee', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.rawtherapee.RawTherapee' }
    },
    detection: { windows: { type: 'winget', checkValue: 'RawTherapee.RawTherapee' } },
    tags: ['raw', 'photo', 'processing']
  },
  {
    id: 'imagemagick',
    name: 'ImageMagick',
    category: 'Image & Design',
    description: 'Command-line tool suite to create, edit, compose, and convert bitmap images.',
    publisher: 'ImageMagick Studio LLC',
    website: 'https://imagemagick.org/',
    downloadPage: 'https://imagemagick.org/script/download.php',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'ImageMagick.ImageMagick' },
      macos: { manager: 'brew', packageId: 'imagemagick', cask: false },
      linux: { manager: 'flatpak', packageId: 'org.imagemagick.ImageMagick' }
    },
    detection: { windows: { type: 'winget', checkValue: 'ImageMagick.ImageMagick' } },
    tags: ['cli', 'converter', 'image-processing']
  },
  {
    id: 'xnviewmp',
    name: 'XnView MP',
    category: 'Image & Design',
    description: 'Versatile photo viewer, image organizer, and batch image converter.',
    publisher: 'XnSoft',
    website: 'https://www.xnview.com/en/xnviewmp/',
    downloadPage: 'https://www.xnview.com/en/xnviewmp/#downloads',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'XnSoft.XnViewMP' },
      macos: { manager: 'brew', packageId: 'xnviewmp', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.xnview.XnViewMP' }
    },
    detection: { windows: { type: 'winget', checkValue: 'XnSoft.XnViewMP' } },
    tags: ['viewer', 'converter', 'batch']
  },
  {
    id: 'irfanview',
    name: 'IrfanView',
    category: 'Image & Design',
    description: 'Fast, compact, and innovative graphic viewer for Windows.',
    publisher: 'Irfan Skiljan',
    website: 'https://www.irfanview.com/',
    downloadPage: 'https://www.irfanview.com/main_download_engl.htm',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'IrfanSkiljan.IrfanView' }
    },
    detection: { windows: { type: 'winget', checkValue: 'IrfanSkiljan.IrfanView' } },
    tags: ['viewer', 'fast', 'windows']
  },
  {
    id: 'faststone-viewer',
    name: 'FastStone Image Viewer',
    category: 'Image & Design',
    description: 'User-friendly image browser, converter, and editor with full-screen viewer.',
    publisher: 'FastStone Soft',
    website: 'https://www.faststone.org/',
    downloadPage: 'https://www.faststone.org/FSViewerDownload.htm',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'FastStone.Viewer' }
    },
    detection: { windows: { type: 'winget', checkValue: 'FastStone.Viewer' } },
    tags: ['viewer', 'browser', 'photo']
  },
  {
    id: 'davinci-resolve',
    name: 'DaVinci Resolve',
    category: 'Image & Design',
    description: 'Hollywood standard solution for video editing, color correction, visual effects, and audio.',
    publisher: 'Blackmagic Design',
    website: 'https://www.blackmagicdesign.com/products/davinciresolve',
    downloadPage: 'https://www.blackmagicdesign.com/products/davinciresolve',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'BlackmagicDesign.DaVinciResolve' },
      macos: { manager: 'brew', packageId: 'davinci-resolve', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'BlackmagicDesign.DaVinciResolve' } },
    tags: ['video', 'editing', 'color-grading', 'vfx']
  },
  {
    id: 'figma',
    name: 'Figma',
    category: 'Image & Design',
    description: 'The collaborative interface design and prototyping tool.',
    publisher: 'Figma, Inc.',
    website: 'https://www.figma.com/',
    downloadPage: 'https://www.figma.com/downloads/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Figma.Figma' },
      macos: { manager: 'brew', packageId: 'figma', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Figma.Figma' } },
    tags: ['ui', 'ux', 'design', 'prototyping']
  },
  {
    id: 'penpot-desktop',
    name: 'Penpot Desktop',
    category: 'Image & Design',
    description: 'Open source design and prototyping platform for product teams.',
    publisher: 'Penpot Community',
    website: 'https://penpot.app/',
    downloadPage: 'https://penpot.app/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KorPrivate.PenpotDesktop' },
      macos: { manager: 'brew', packageId: 'penpot', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'KorPrivate.PenpotDesktop' } },
    tags: ['design', 'open-source', 'vector']
  },

  // 5. DOCUMENTS & PDFS (15)
  {
    id: 'libreoffice',
    name: 'LibreOffice',
    category: 'Documents & PDFs',
    description: 'Leading open source office suite compatible with Word, Excel, PowerPoint.',
    publisher: 'The Document Foundation',
    website: 'https://www.libreoffice.org/',
    downloadPage: 'https://www.libreoffice.org/download/download-libreoffice/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'TheDocumentFoundation.LibreOffice' },
      macos: { manager: 'brew', packageId: 'libreoffice', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.libreoffice.LibreOffice' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TheDocumentFoundation.LibreOffice' } },
    tags: ['office', 'word', 'spreadsheet', 'presentation'],
    featured: true
  },
  {
    id: 'onlyoffice',
    name: 'ONLYOFFICE Desktop Editors',
    category: 'Documents & PDFs',
    description: 'High compatibility office suite for documents, spreadsheets, presentations, and forms.',
    publisher: 'Ascensio System SIA',
    website: 'https://www.onlyoffice.com/',
    downloadPage: 'https://www.onlyoffice.com/download-desktop.aspx',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'AscensioSystem.OnlyOffice' },
      macos: { manager: 'brew', packageId: 'onlyoffice', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.onlyoffice.desktopeditors' }
    },
    detection: { windows: { type: 'winget', checkValue: 'AscensioSystem.OnlyOffice' } },
    tags: ['office', 'docx', 'xlsx', 'documents']
  },
  {
    id: 'openoffice',
    name: 'Apache OpenOffice',
    category: 'Documents & PDFs',
    description: 'Classic open-source office software suite for word processing and data handling.',
    publisher: 'Apache Software Foundation',
    website: 'https://www.openoffice.org/',
    downloadPage: 'https://www.openoffice.org/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Apache.OpenOffice' },
      macos: { manager: 'brew', packageId: 'openoffice', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Apache.OpenOffice' } },
    tags: ['office', 'apache', 'legacy']
  },
  {
    id: 'sumatrapdf',
    name: 'SumatraPDF',
    category: 'Documents & PDFs',
    description: 'Ultra-lightweight, blazing fast PDF, eBook (ePub, MOBI), and comic book reader.',
    publisher: 'Krzysztof Kowalczyk',
    website: 'https://www.sumatrapdfreader.org/',
    downloadPage: 'https://www.sumatrapdfreader.org/download-free-pdf-viewer',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KrzysztofKowalczyk.SumatraPDF' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KrzysztofKowalczyk.SumatraPDF' } },
    tags: ['pdf', 'reader', 'fast', 'lightweight'],
    featured: true
  },
  {
    id: 'okular',
    name: 'Okular',
    category: 'Documents & PDFs',
    description: 'Universal document viewer with support for PDF, Postscript, DjVu, CHM, and comics.',
    publisher: 'KDE Community',
    website: 'https://okular.kde.org/',
    downloadPage: 'https://okular.kde.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KDE.Okular' },
      macos: { manager: 'brew', packageId: 'okular', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.kde.okular' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KDE.Okular' } },
    tags: ['pdf', 'documents', 'annotations', 'kde']
  },
  {
    id: 'pdf24',
    name: 'PDF24 Creator',
    category: 'Documents & PDFs',
    description: 'Free toolbox for merging, splitting, compressing, and editing PDF files locally.',
    publisher: 'geek software GmbH',
    website: 'https://www.pdf24.org/',
    downloadPage: 'https://tools.pdf24.org/en/creator',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'GeekSoftwareGmbH.PDF24Creator' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GeekSoftwareGmbH.PDF24Creator' } },
    tags: ['pdf', 'creator', 'merge', 'tools']
  },
  {
    id: 'foxit-reader',
    name: 'Foxit PDF Reader',
    category: 'Documents & PDFs',
    description: 'Full-featured PDF viewer with annotations, form filling, and digital signing.',
    publisher: 'Foxit Software',
    website: 'https://www.foxit.com/pdf-reader/',
    downloadPage: 'https://www.foxit.com/pdf-reader/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Foxit.FoxitReader' },
      macos: { manager: 'brew', packageId: 'foxitreader', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Foxit.FoxitReader' } },
    tags: ['pdf', 'reader', 'forms']
  },
  {
    id: 'ghostscript',
    name: 'Ghostscript',
    category: 'Documents & PDFs',
    description: 'Interpreter for the PostScript language and for PDF files.',
    publisher: 'Artifex Software, Inc.',
    website: 'https://www.ghostscript.com/',
    downloadPage: 'https://www.ghostscript.com/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'ArtifexSoftware.Ghostscript' },
      macos: { manager: 'brew', packageId: 'ghostscript', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'ArtifexSoftware.Ghostscript' } },
    tags: ['pdf', 'postscript', 'interpreter']
  },
  {
    id: 'pandoc',
    name: 'Pandoc',
    category: 'Documents & PDFs',
    description: 'Universal document converter supporting Markdown, HTML, LaTeX, Docx, PDF, and EPUB.',
    publisher: 'John MacFarlane',
    website: 'https://pandoc.org/',
    downloadPage: 'https://pandoc.org/installing.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'JohnMacFarlane.Pandoc' },
      macos: { manager: 'brew', packageId: 'pandoc', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'JohnMacFarlane.Pandoc' } },
    tags: ['converter', 'markdown', 'cli', 'documents']
  },
  {
    id: 'calibre',
    name: 'Calibre',
    category: 'Documents & PDFs',
    description: 'The one-stop solution for all your e-book needs: manage, convert, read, and sync.',
    publisher: 'Kovid Goyal',
    website: 'https://calibre-ebook.com/',
    downloadPage: 'https://calibre-ebook.com/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KovidGoyal.Calibre' },
      macos: { manager: 'brew', packageId: 'calibre', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.calibre_ebook.calibre' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KovidGoyal.Calibre' } },
    tags: ['ebook', 'epub', 'mobi', 'kindle']
  },
  {
    id: 'zotero',
    name: 'Zotero',
    category: 'Documents & PDFs',
    description: 'Free, easy-to-use research tool to help you collect, organize, annotate, cite, and share research.',
    publisher: 'Corporation for Digital Scholarship',
    website: 'https://www.zotero.org/',
    downloadPage: 'https://www.zotero.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'DigitalScholar.Zotero' },
      macos: { manager: 'brew', packageId: 'zotero', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.zotero.Zotero' }
    },
    detection: { windows: { type: 'winget', checkValue: 'DigitalScholar.Zotero' } },
    tags: ['research', 'citation', 'bibliography', 'academic']
  },
  {
    id: 'obsidian',
    name: 'Obsidian',
    category: 'Documents & PDFs',
    description: 'Sharpen your thinking with private, extensible Markdown notes stored locally.',
    publisher: 'Dynalist Inc.',
    website: 'https://obsidian.md/',
    downloadPage: 'https://obsidian.md/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Obsidian.Obsidian' },
      macos: { manager: 'brew', packageId: 'obsidian', cask: true },
      linux: { manager: 'flatpak', packageId: 'md.obsidian.Obsidian' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Obsidian.Obsidian' } },
    tags: ['notes', 'markdown', 'knowledge-graph', 'pkm'],
    featured: true
  },
  {
    id: 'joplin',
    name: 'Joplin',
    category: 'Documents & PDFs',
    description: 'Open source note taking and to-do application with end-to-end synchronization.',
    publisher: 'Laurent Cozic',
    website: 'https://joplinapp.org/',
    downloadPage: 'https://joplinapp.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'LaurentCozic.Joplin' },
      macos: { manager: 'brew', packageId: 'joplin', cask: true },
      linux: { manager: 'flatpak', packageId: 'net.cozic.joplin_desktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'LaurentCozic.Joplin' } },
    tags: ['notes', 'e2ee', 'markdown', 'tasks']
  },
  {
    id: 'logseq',
    name: 'Logseq',
    category: 'Documents & PDFs',
    description: 'Privacy-first, open-source platform for knowledge management and collaboration.',
    publisher: 'Logseq, Inc.',
    website: 'https://logseq.com/',
    downloadPage: 'https://logseq.com/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Logseq.Logseq' },
      macos: { manager: 'brew', packageId: 'logseq', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.logseq.Logseq' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Logseq.Logseq' } },
    tags: ['outliner', 'knowledge-base', 'markdown']
  },
  {
    id: 'notion',
    name: 'Notion',
    category: 'Documents & PDFs',
    description: 'Connected workspace where better, faster work happens with docs and projects.',
    publisher: 'Notion Labs, Inc.',
    website: 'https://www.notion.so/',
    downloadPage: 'https://www.notion.so/desktop',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Notion.Notion' },
      macos: { manager: 'brew', packageId: 'notion', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Notion.Notion' } },
    tags: ['workspace', 'docs', 'wiki', 'notes']
  },

  // 6. COMPRESSION & FILE MANAGEMENT (13)
  {
    id: '7zip',
    name: '7-Zip',
    category: 'Compression & File Management',
    description: 'High-ratio file archiver with 7z, ZIP, RAR, TAR, GZ, and LZMA support.',
    publisher: 'Igor Pavlov',
    website: 'https://www.7-zip.org/',
    downloadPage: 'https://www.7-zip.org/download.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: '7zip.7zip' },
      macos: { manager: 'brew', packageId: 'sevenzip', cask: false },
      linux: { manager: 'flatpak', packageId: 'org.sevenzip.7zip' }
    },
    detection: { windows: { type: 'winget', checkValue: '7zip.7zip' } },
    tags: ['compression', 'zip', 'archive', '7z'],
    featured: true
  },
  {
    id: 'peazip',
    name: 'PeaZip',
    category: 'Compression & File Management',
    description: 'Free file archiver utility supporting over 200 archive formats with strong encryption.',
    publisher: 'Giorgio Tani',
    website: 'https://peazip.github.io/',
    downloadPage: 'https://peazip.github.io/peazip-free-archiver.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GiorgioTani.PeaZip' },
      macos: { manager: 'brew', packageId: 'peazip', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.github.peazip.PeaZip' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GiorgioTani.PeaZip' } },
    tags: ['archiver', 'encryption', 'open-source']
  },
  {
    id: 'nanazip',
    name: 'NanaZip',
    category: 'Compression & File Management',
    description: 'Modern 7-Zip fork built natively for Windows 11 with modern context menu support.',
    publisher: 'M2-Team',
    website: 'https://github.com/M2Team/NanaZip',
    downloadPage: 'https://github.com/M2Team/NanaZip/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'M2Team.NanaZip' }
    },
    detection: { windows: { type: 'winget', checkValue: 'M2Team.NanaZip' } },
    tags: ['win11', 'context-menu', 'modern-zip']
  },
  {
    id: 'winrar',
    name: 'WinRAR',
    category: 'Compression & File Management',
    description: 'Popular powerful archive manager with high compression ratio and recovery records.',
    publisher: 'win.rar GmbH',
    website: 'https://www.rarlab.com/',
    downloadPage: 'https://www.rarlab.com/download.htm',
    license: 'Trialware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RARLab.WinRAR' },
      macos: { manager: 'brew', packageId: 'rar', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'RARLab.WinRAR' } },
    tags: ['rar', 'zip', 'archiver']
  },
  {
    id: 'freefilesync',
    name: 'FreeFileSync',
    category: 'Compression & File Management',
    description: 'Folder comparison and synchronization software that optimizes execution.',
    publisher: 'Zenju',
    website: 'https://freefilesync.org/',
    downloadPage: 'https://freefilesync.org/download.php',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Zenju.FreeFileSync' },
      macos: { manager: 'brew', packageId: 'freefilesync', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.freefilesync.FreeFileSync' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Zenju.FreeFileSync' } },
    tags: ['sync', 'backup', 'mirror']
  },
  {
    id: 'doublecommander',
    name: 'Double Commander',
    category: 'Compression & File Management',
    description: 'Cross platform open source two-panel file manager inspired by Total Commander.',
    publisher: 'Double Commander Community',
    website: 'https://doublecmd.sourceforge.io/',
    downloadPage: 'https://doublecmd.sourceforge.io/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'DoubleCommander.DoubleCommander' },
      macos: { manager: 'brew', packageId: 'double-commander', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.github.doublecmd.DoubleCommander' }
    },
    detection: { windows: { type: 'winget', checkValue: 'DoubleCommander.DoubleCommander' } },
    tags: ['file-manager', 'dual-pane', 'commander']
  },
  {
    id: 'files-app',
    name: 'Files App',
    category: 'Compression & File Management',
    description: 'Elegant, modern file manager for Windows built with Fluent Design and tabs.',
    publisher: 'Files Community',
    website: 'https://files.community/',
    downloadPage: 'https://files.community/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Files-Community.Files' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Files-Community.Files' } },
    tags: ['explorer', 'tabs', 'fluent', 'modern']
  },
  {
    id: 'everything',
    name: 'Everything',
    category: 'Compression & File Management',
    description: 'Instant filename search engine that indexes gigabytes of drives in seconds.',
    publisher: 'voidtools',
    website: 'https://www.voidtools.com/',
    downloadPage: 'https://www.voidtools.com/downloads/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'voidtools.Everything' }
    },
    detection: { windows: { type: 'winget', checkValue: 'voidtools.Everything' } },
    tags: ['search', 'fast', 'index', 'ntfs'],
    featured: true
  },
  {
    id: 'wiztree',
    name: 'WizTree',
    category: 'Compression & File Management',
    description: 'The world\'s fastest disk space analyzer scanning the Master File Table directly.',
    publisher: 'Antibody Software',
    website: 'https://diskanalyzer.com/',
    downloadPage: 'https://diskanalyzer.com/download',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'AntibodySoftware.WizTree' }
    },
    detection: { windows: { type: 'winget', checkValue: 'AntibodySoftware.WizTree' } },
    tags: ['disk-usage', 'mft', 'cleaner', 'storage']
  },
  {
    id: 'windirstat',
    name: 'WinDirStat',
    category: 'Compression & File Management',
    description: 'Disk usage statistics viewer and cleanup tool with treemap visualization.',
    publisher: 'WinDirStat Team',
    website: 'https://windirstat.net/',
    downloadPage: 'https://windirstat.net/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'WinDirStat.WinDirStat' }
    },
    detection: { windows: { type: 'winget', checkValue: 'WinDirStat.WinDirStat' } },
    tags: ['disk', 'storage', 'treemap']
  },
  {
    id: 'teracopy',
    name: 'TeraCopy',
    category: 'Compression & File Management',
    description: 'Accelerate file transfers, verify checksums, and skip problematic files gracefully.',
    publisher: 'Code Sector',
    website: 'https://www.codesector.com/teracopy',
    downloadPage: 'https://www.codesector.com/downloads',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'CodeSector.TeraCopy' }
    },
    detection: { windows: { type: 'winget', checkValue: 'CodeSector.TeraCopy' } },
    tags: ['copy', 'transfer', 'checksum', 'speed']
  },
  {
    id: 'syncthing',
    name: 'Syncthing',
    category: 'Compression & File Management',
    description: 'Continuous file synchronization program that syncs files directly between devices securely.',
    publisher: 'The Syncthing Foundation',
    website: 'https://syncthing.net/',
    downloadPage: 'https://syncthing.net/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Syncthing.Syncthing' },
      macos: { manager: 'brew', packageId: 'syncthing', cask: false },
      linux: { manager: 'flatpak', packageId: 'me.kozec.syncthingtk' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Syncthing.Syncthing' } },
    tags: ['p2p', 'sync', 'private', 'decentralized']
  },
  {
    id: 'qdir',
    name: 'Q-Dir',
    category: 'Compression & File Management',
    description: 'Quad-Explorer file manager making file navigation across 4 panes easy.',
    publisher: 'Nenad Hrg',
    website: 'https://www.softwareok.com/?seite=Freeware/Q-Dir',
    downloadPage: 'https://www.softwareok.com/?seite=Freeware/Q-Dir',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'NenadHrg.Q-Dir' }
    },
    detection: { windows: { type: 'winget', checkValue: 'NenadHrg.Q-Dir' } },
    tags: ['quad-pane', 'file-explorer']
  },

  // 7. SECURITY & PASSWORD MANAGERS (10)
  {
    id: 'bitwarden',
    name: 'Bitwarden',
    category: 'Security & Password Managers',
    description: 'Open source password manager protecting passwords and sensitive info with zero-knowledge encryption.',
    publisher: 'Bitwarden, Inc.',
    website: 'https://bitwarden.com/',
    downloadPage: 'https://bitwarden.com/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Bitwarden.Bitwarden' },
      macos: { manager: 'brew', packageId: 'bitwarden', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.bitwarden.desktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Bitwarden.Bitwarden' } },
    tags: ['password', 'vault', 'security', 'zero-knowledge'],
    featured: true
  },
  {
    id: 'keepassxc',
    name: 'KeePassXC',
    category: 'Security & Password Managers',
    description: 'Community-driven, cross-platform port of KeePass storing passwords in local encrypted KDBX files.',
    publisher: 'KeePassXC Team',
    website: 'https://keepassxc.org/',
    downloadPage: 'https://keepassxc.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KeePassXCTeam.KeePassXC' },
      macos: { manager: 'brew', packageId: 'keepassxc', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.keepassxc.KeePassXC' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KeePassXCTeam.KeePassXC' } },
    tags: ['password', 'kdbx', 'offline', 'encryption']
  },
  {
    id: 'keepass2',
    name: 'KeePass Password Safe',
    category: 'Security & Password Managers',
    description: 'The original lightweight password manager for Windows with plugin architecture.',
    publisher: 'Dominik Reichl',
    website: 'https://keepass.info/',
    downloadPage: 'https://keepass.info/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'DominikReichl.KeePass' }
    },
    detection: { windows: { type: 'winget', checkValue: 'DominikReichl.KeePass' } },
    tags: ['password', 'security', 'classic']
  },
  {
    id: 'onepassword',
    name: '1Password',
    category: 'Security & Password Managers',
    description: 'Premium password manager with Watchtower security alerts and biometrics support.',
    publisher: 'AgileBits Inc.',
    website: 'https://1password.com/',
    downloadPage: 'https://1password.com/downloads/',
    license: 'Proprietary',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'AgileBits.1Password' },
      macos: { manager: 'brew', packageId: '1password', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.onepassword.OnePassword' }
    },
    detection: { windows: { type: 'winget', checkValue: 'AgileBits.1Password' } },
    tags: ['passwords', 'watchtower', 'passkeys']
  },
  {
    id: 'veracrypt',
    name: 'VeraCrypt',
    category: 'Security & Password Managers',
    description: 'Free open source disk encryption software based on TrueCrypt with enhanced algorithms.',
    publisher: 'IDRIX',
    website: 'https://www.veracrypt.fr/',
    downloadPage: 'https://www.veracrypt.fr/en/Downloads.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'IDRIX.VeraCrypt' },
      macos: { manager: 'brew', packageId: 'veracrypt', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'IDRIX.VeraCrypt' } },
    tags: ['encryption', 'disk', 'container', 'security']
  },
  {
    id: 'malwarebytes',
    name: 'Malwarebytes',
    category: 'Security & Password Managers',
    description: 'Anti-malware tool detecting and eliminating advanced threats and ransomware.',
    publisher: 'Malwarebytes Inc.',
    website: 'https://www.malwarebytes.com/',
    downloadPage: 'https://www.malwarebytes.com/mwb-download',
    license: 'Freemium',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Malwarebytes.Malwarebytes' },
      macos: { manager: 'brew', packageId: 'malwarebytes', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Malwarebytes.Malwarebytes' } },
    tags: ['antivirus', 'malware', 'cleaner']
  },
  {
    id: 'cryptomator',
    name: 'Cryptomator',
    category: 'Security & Password Managers',
    description: 'Multi-platform transparent client-side encryption for cloud storage files.',
    publisher: 'Skymatic GmbH',
    website: 'https://cryptomator.org/',
    downloadPage: 'https://cryptomator.org/downloads/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Cryptomator.Cryptomator' },
      macos: { manager: 'brew', packageId: 'cryptomator', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.cryptomator.Cryptomator' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Cryptomator.Cryptomator' } },
    tags: ['cloud-encryption', 'vault', 'zero-knowledge']
  },
  {
    id: 'gpg4win',
    name: 'Gpg4win',
    category: 'Security & Password Managers',
    description: 'Secure solution for file and email encryption in Windows using OpenPGP and S/MIME.',
    publisher: 'GnuPG project',
    website: 'https://gpg4win.org/',
    downloadPage: 'https://gpg4win.org/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'GnuPG.Gpg4win' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GnuPG.Gpg4win' } },
    tags: ['pgp', 'gpg', 'kleopatra', 'crypto']
  },
  {
    id: 'proton-pass',
    name: 'Proton Pass',
    category: 'Security & Password Managers',
    description: 'End-to-end encrypted password and email alias manager developed by Swiss Proton.',
    publisher: 'Proton AG',
    website: 'https://proton.me/pass',
    downloadPage: 'https://proton.me/pass/download',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Proton.ProtonPass' },
      macos: { manager: 'brew', packageId: 'proton-pass', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Proton.ProtonPass' } },
    tags: ['proton', 'passwords', 'privacy', 'swiss']
  },
  {
    id: 'authy',
    name: 'Authy Desktop',
    category: 'Security & Password Managers',
    description: 'Two-factor authentication client with multi-device encrypted backups.',
    publisher: 'Twilio Inc.',
    website: 'https://authy.com/',
    downloadPage: 'https://authy.com/download/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Twilio.Authy' },
      macos: { manager: 'brew', packageId: 'authy', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Twilio.Authy' } },
    tags: ['2fa', 'totp', 'security']
  },

  // 8. CLOUD STORAGE & SYNC (8)
  {
    id: 'dropbox',
    name: 'Dropbox',
    category: 'Cloud Storage & Sync',
    description: 'Cloud storage and file synchronization with seamless smart sync and file sharing.',
    publisher: 'Dropbox, Inc.',
    website: 'https://www.dropbox.com/',
    downloadPage: 'https://www.dropbox.com/install',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Dropbox.Dropbox' },
      macos: { manager: 'brew', packageId: 'dropbox', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.dropbox.Client' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Dropbox.Dropbox' } },
    tags: ['cloud', 'sync', 'backup', 'storage'],
    featured: true
  },
  {
    id: 'google-drive',
    name: 'Google Drive for Desktop',
    category: 'Cloud Storage & Sync',
    description: 'Sync files between Google Drive and your local drive with virtual streaming.',
    publisher: 'Google LLC',
    website: 'https://www.google.com/drive/',
    downloadPage: 'https://www.google.com/drive/download/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Google.GoogleDrive' },
      macos: { manager: 'brew', packageId: 'google-drive', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Google.GoogleDrive' } },
    tags: ['cloud', 'google', 'sync', 'drive']
  },
  {
    id: 'onedrive',
    name: 'Microsoft OneDrive',
    category: 'Cloud Storage & Sync',
    description: 'Cloud backup and synchronization deeply built into Windows and Microsoft 365.',
    publisher: 'Microsoft Corporation',
    website: 'https://www.microsoft.com/onedrive',
    downloadPage: 'https://www.microsoft.com/onedrive/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.OneDrive' },
      macos: { manager: 'brew', packageId: 'onedrive', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.OneDrive' } },
    tags: ['cloud', 'microsoft', 'backup']
  },
  {
    id: 'nextcloud',
    name: 'Nextcloud Desktop',
    category: 'Cloud Storage & Sync',
    description: 'Self-hosted productivity platform keeping your data fully under your control.',
    publisher: 'Nextcloud GmbH',
    website: 'https://nextcloud.com/',
    downloadPage: 'https://nextcloud.com/install/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Nextcloud.NextcloudDesktop' },
      macos: { manager: 'brew', packageId: 'nextcloud', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.nextcloud.desktopclient.nextcloud' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Nextcloud.NextcloudDesktop' } },
    tags: ['self-hosted', 'cloud', 'private', 'open-source']
  },
  {
    id: 'proton-drive',
    name: 'Proton Drive',
    category: 'Cloud Storage & Sync',
    description: 'Encrypted cloud storage from the makers of Proton Mail ensuring absolute privacy.',
    publisher: 'Proton AG',
    website: 'https://proton.me/drive',
    downloadPage: 'https://proton.me/drive/download',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Proton.ProtonDrive' },
      macos: { manager: 'brew', packageId: 'proton-drive', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Proton.ProtonDrive' } },
    tags: ['e2ee', 'cloud', 'swiss', 'privacy']
  },
  {
    id: 'rclone',
    name: 'rclone',
    category: 'Cloud Storage & Sync',
    description: 'The Swiss army knife of cloud storage: rsync for 70+ cloud providers.',
    publisher: 'Nick Craig-Wood',
    website: 'https://rclone.org/',
    downloadPage: 'https://rclone.org/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Rclone.Rclone' },
      macos: { manager: 'brew', packageId: 'rclone', cask: false },
      linux: { manager: 'flatpak', packageId: 'org.rclone.Rclone' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Rclone.Rclone' } },
    tags: ['cloud', 'cli', 's3', 'backup']
  },
  {
    id: 'mega-sync',
    name: 'MEGAsync',
    category: 'Cloud Storage & Sync',
    description: 'Easy automated syncing between your computers and your MEGA Cloud Drive.',
    publisher: 'Mega Limited',
    website: 'https://mega.io/',
    downloadPage: 'https://mega.io/desktop',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Mega.MEGAsync' },
      macos: { manager: 'brew', packageId: 'megasync', cask: true },
      linux: { manager: 'flatpak', packageId: 'nz.mega.MEGAsync' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Mega.MEGAsync' } },
    tags: ['cloud', 'mega', 'e2ee']
  },
  {
    id: 'pcloud',
    name: 'pCloud Drive',
    category: 'Cloud Storage & Sync',
    description: 'Virtual cloud drive client giving you extra cloud storage without taking disk space.',
    publisher: 'pCloud AG',
    website: 'https://www.pcloud.com/',
    downloadPage: 'https://www.pcloud.com/download-free-online-cloud-file-storage.html',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'pCloud.pCloudDrive' },
      macos: { manager: 'brew', packageId: 'pcloud-drive', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'pCloud.pCloudDrive' } },
    tags: ['cloud', 'virtual-drive', 'backup']
  },

  // 9. GAMING & GAME DEV (16)
  {
    id: 'steam',
    name: 'Steam',
    category: 'Gaming & Game Dev',
    description: 'The ultimate entertainment platform for playing, connecting, and creating games.',
    publisher: 'Valve Corporation',
    website: 'https://store.steampowered.com/',
    downloadPage: 'https://store.steampowered.com/about/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Valve.Steam' },
      macos: { manager: 'brew', packageId: 'steam', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.valvesoftware.Steam' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Valve.Steam' } },
    tags: ['games', 'store', 'valve', 'pc-gaming'],
    featured: true
  },
  {
    id: 'epic-games-launcher',
    name: 'Epic Games Launcher',
    category: 'Gaming & Game Dev',
    description: 'Gateway to Unreal Engine, Fortnite, Rocket League, and weekly free games.',
    publisher: 'Epic Games, Inc.',
    website: 'https://store.epicgames.com/',
    downloadPage: 'https://store.epicgames.com/download',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'EpicGames.EpicGamesLauncher' },
      macos: { manager: 'brew', packageId: 'epic-games', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'EpicGames.EpicGamesLauncher' } },
    tags: ['epic', 'fortnite', 'unreal-engine', 'launcher']
  },
  {
    id: 'gog-galaxy',
    name: 'GOG GALAXY',
    category: 'Gaming & Game Dev',
    description: 'All-in-one game launcher bringing all your game libraries and friends together DRM-free.',
    publisher: 'GOG sp. z o.o.',
    website: 'https://www.gog.com/galaxy',
    downloadPage: 'https://www.gog.com/galaxy',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GOG.Galaxy' },
      macos: { manager: 'brew', packageId: 'gog-galaxy', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'GOG.Galaxy' } },
    tags: ['drm-free', 'gog', 'unified-launcher']
  },
  {
    id: 'heroic-games-launcher',
    name: 'Heroic Games Launcher',
    category: 'Gaming & Game Dev',
    description: 'Open source games launcher for Epic Games, GOG, and Prime Gaming.',
    publisher: 'Heroic Games Launcher Community',
    website: 'https://heroicgameslauncher.com/',
    downloadPage: 'https://heroicgameslauncher.com/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'HeroicGamesLauncher.HeroicGamesLauncher' },
      macos: { manager: 'brew', packageId: 'heroic', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.heroicgameslauncher.hgl' }
    },
    detection: { windows: { type: 'winget', checkValue: 'HeroicGamesLauncher.HeroicGamesLauncher' } },
    tags: ['open-source', 'epic', 'gog', 'cross-platform']
  },
  {
    id: 'lutris',
    name: 'Lutris',
    category: 'Gaming & Game Dev',
    description: 'Open gaming platform for Linux to install and launch video games seamlessly.',
    publisher: 'Lutris Community',
    website: 'https://lutris.net/',
    downloadPage: 'https://lutris.net/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['linux'],
    architectures: ['x64'],
    packages: {
      linux: { manager: 'flatpak', packageId: 'net.lutris.Lutris' }
    },
    detection: {},
    tags: ['linux-gaming', 'wine', 'proton']
  },
  {
    id: 'prism-launcher',
    name: 'Prism Launcher',
    category: 'Gaming & Game Dev',
    description: 'Custom open source Minecraft launcher with multiple instances and modpack support.',
    publisher: 'Prism Launcher Team',
    website: 'https://prismlauncher.org/',
    downloadPage: 'https://prismlauncher.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'PrismLauncher.PrismLauncher' },
      macos: { manager: 'brew', packageId: 'prismlauncher', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.prismlauncher.PrismLauncher' }
    },
    detection: { windows: { type: 'winget', checkValue: 'PrismLauncher.PrismLauncher' } },
    tags: ['minecraft', 'mods', 'curseforge', 'modrinth']
  },
  {
    id: 'minecraft-launcher',
    name: 'Minecraft Launcher',
    category: 'Gaming & Game Dev',
    description: 'Official launcher for Minecraft: Java Edition and Minecraft: Bedrock Edition.',
    publisher: 'Mojang Studios',
    website: 'https://www.minecraft.net/',
    downloadPage: 'https://www.minecraft.net/en-us/download',
    license: 'Proprietary',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Mojang.MinecraftLauncher' },
      macos: { manager: 'brew', packageId: 'minecraft', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.mojang.Minecraft' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Mojang.MinecraftLauncher' } },
    tags: ['minecraft', 'sandbox', 'gaming']
  },
  {
    id: 'itchio',
    name: 'itch.io Desktop App',
    category: 'Gaming & Game Dev',
    description: 'The desktop client to browse, download, and update indie games from itch.io.',
    publisher: 'itch corp',
    website: 'https://itch.io/app',
    downloadPage: 'https://itch.io/app',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'itchio.itch' },
      macos: { manager: 'brew', packageId: 'itch', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.itch.itch' }
    },
    detection: { windows: { type: 'winget', checkValue: 'itchio.itch' } },
    tags: ['indie', 'games', 'game-dev']
  },
  {
    id: 'ea-app',
    name: 'EA app',
    category: 'Gaming & Game Dev',
    description: 'Electronic Arts enhanced PC gaming platform replacing Origin.',
    publisher: 'Electronic Arts Inc.',
    website: 'https://www.ea.com/ea-app',
    downloadPage: 'https://www.ea.com/ea-app',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'ElectronicArts.EADesktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'ElectronicArts.EADesktop' } },
    tags: ['ea', 'origin', 'gaming', 'fifa']
  },
  {
    id: 'battlenet',
    name: 'Battle.net',
    category: 'Gaming & Game Dev',
    description: 'Blizzard Entertainment gaming platform for World of Warcraft, Overwatch, and Diablo.',
    publisher: 'Blizzard Entertainment',
    website: 'https://www.blizzard.com/en-us/apps/battle.net/desktop',
    downloadPage: 'https://www.blizzard.com/en-us/apps/battle.net/desktop',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Blizzard.BattleNet' },
      macos: { manager: 'brew', packageId: 'battle-net', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Blizzard.BattleNet' } },
    tags: ['blizzard', 'warcraft', 'overwatch', 'diablo']
  },
  {
    id: 'ubisoft-connect',
    name: 'Ubisoft Connect',
    category: 'Gaming & Game Dev',
    description: 'Ecosystem of player services and PC launcher for Ubisoft games.',
    publisher: 'Ubisoft',
    website: 'https://ubisoftconnect.com/',
    downloadPage: 'https://ubisoftconnect.com/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Ubisoft.Connect' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Ubisoft.Connect' } },
    tags: ['ubisoft', 'assassins-creed', 'launcher']
  },
  {
    id: 'godot',
    name: 'Godot Engine',
    category: 'Gaming & Game Dev',
    description: 'Free, open source 2D and 3D game engine with dedicated language and visual editors.',
    publisher: 'Godot Engine Community',
    website: 'https://godotengine.org/',
    downloadPage: 'https://godotengine.org/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GodotEngine.GodotEngine' },
      macos: { manager: 'brew', packageId: 'godot', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.godotengine.Godot' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GodotEngine.GodotEngine' } },
    tags: ['game-engine', '2d', '3d', 'open-source'],
    featured: true
  },
  {
    id: 'unity-hub',
    name: 'Unity Hub',
    category: 'Gaming & Game Dev',
    description: 'Standalone application to manage Unity Editor installations, projects, and licenses.',
    publisher: 'Unity Technologies',
    website: 'https://unity.com/',
    downloadPage: 'https://unity.com/download',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'UnityTechnologies.UnityHub' },
      macos: { manager: 'brew', packageId: 'unity-hub', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.unity.UnityHub' }
    },
    detection: { windows: { type: 'winget', checkValue: 'UnityTechnologies.UnityHub' } },
    tags: ['unity', 'game-dev', '3d', 'csharp']
  },
  {
    id: 'playnite',
    name: 'Playnite',
    category: 'Gaming & Game Dev',
    description: 'Open source video game library manager with support for 3rd party libraries and emulation.',
    publisher: 'Josef Nemec',
    website: 'https://playnite.link/',
    downloadPage: 'https://playnite.link/download.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Playnite.Playnite' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Playnite.Playnite' } },
    tags: ['launcher', 'fullscreen', 'emulation', 'open-source']
  },
  {
    id: 'moonlight',
    name: 'Moonlight Game Streaming',
    category: 'Gaming & Game Dev',
    description: 'Open source client for Sunshine and NVIDIA GameStream for ultra low-latency gaming.',
    publisher: 'Moonlight Game Streaming Project',
    website: 'https://moonlight-stream.org/',
    downloadPage: 'https://moonlight-stream.org/#downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'MoonlightGameStreamingProject.Moonlight' },
      macos: { manager: 'brew', packageId: 'moonlight', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.moonlight_stream.Moonlight' }
    },
    detection: { windows: { type: 'winget', checkValue: 'MoonlightGameStreamingProject.Moonlight' } },
    tags: ['streaming', 'remote-gaming', 'sunshine', 'low-latency']
  },
  {
    id: 'retroarch',
    name: 'RetroArch',
    category: 'Gaming & Game Dev',
    description: 'Frontend for emulators, game engines, and media players with run-ahead latency reduction.',
    publisher: 'Libretro',
    website: 'https://www.retroarch.com/',
    downloadPage: 'https://www.retroarch.com/?page=platforms',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Libretro.RetroArch' },
      macos: { manager: 'brew', packageId: 'retroarch', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.libretro.RetroArch' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Libretro.RetroArch' } },
    tags: ['emulation', 'retro', 'libretro']
  },

  // 10. DEVELOPER TOOLS (40: Editors, CLIs, Languages, Databases)
  {
    id: 'vscode',
    name: 'Visual Studio Code',
    category: 'Developer Tools',
    description: 'Streamlined code editor with support for development operations like debugging, task running, and version control.',
    publisher: 'Microsoft Corporation',
    website: 'https://code.visualstudio.com/',
    downloadPage: 'https://code.visualstudio.com/Download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.VisualStudioCode' },
      macos: { manager: 'brew', packageId: 'visual-studio-code', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.visualstudio.code' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.VisualStudioCode' } },
    tags: ['ide', 'editor', 'microsoft', 'typescript'],
    featured: true
  },
  {
    id: 'vscodium',
    name: 'VSCodium',
    category: 'Developer Tools',
    description: 'Free/libre community distribution of Microsoft\'s editor VS Code without telemetry.',
    publisher: 'VSCodium Community',
    website: 'https://vscodium.com/',
    downloadPage: 'https://github.com/VSCodium/vscodium/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'VSCodium.VSCodium' },
      macos: { manager: 'brew', packageId: 'vscodium', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.vscodium.codium' }
    },
    detection: { windows: { type: 'winget', checkValue: 'VSCodium.VSCodium' } },
    tags: ['editor', 'no-telemetry', 'open-source']
  },
  {
    id: 'visual-studio-community',
    name: 'Visual Studio Community 2022',
    category: 'Developer Tools',
    description: 'Comprehensive, full-featured IDE for C++, C#, .NET, and Windows developers.',
    publisher: 'Microsoft Corporation',
    website: 'https://visualstudio.microsoft.com/',
    downloadPage: 'https://visualstudio.microsoft.com/downloads/',
    license: 'Freemium',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.VisualStudio.2022.Community' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.VisualStudio.2022.Community' } },
    tags: ['ide', 'dotnet', 'cplusplus', 'windows-dev']
  },
  {
    id: 'jetbrains-toolbox',
    name: 'JetBrains Toolbox',
    category: 'Developer Tools',
    description: 'Control panel to easily manage, install, and update all JetBrains IDEs and tools.',
    publisher: 'JetBrains s.r.o.',
    website: 'https://www.jetbrains.com/toolbox-app/',
    downloadPage: 'https://www.jetbrains.com/toolbox-app/download/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'JetBrains.Toolbox' },
      macos: { manager: 'brew', packageId: 'jetbrains-toolbox', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.jetbrains.Toolbox' }
    },
    detection: { windows: { type: 'winget', checkValue: 'JetBrains.Toolbox' } },
    tags: ['jetbrains', 'intellij', 'pycharm', 'rider'],
    featured: true
  },
  {
    id: 'git',
    name: 'Git for Windows',
    category: 'Developer Tools',
    description: 'Fast, scalable, distributed revision control system with Git Bash and credential manager.',
    publisher: 'The Git Development Community',
    website: 'https://git-scm.com/',
    downloadPage: 'https://git-scm.com/download/win',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Git.Git' },
      macos: { manager: 'brew', packageId: 'git', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Git.Git' } },
    tags: ['vcs', 'git', 'cli', 'version-control'],
    featured: true
  },
  {
    id: 'github-desktop',
    name: 'GitHub Desktop',
    category: 'Developer Tools',
    description: 'Seamless Git workflow GUI client created and maintained by GitHub.',
    publisher: 'GitHub, Inc.',
    website: 'https://desktop.github.com/',
    downloadPage: 'https://desktop.github.com/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GitHub.GitHubDesktop' },
      macos: { manager: 'brew', packageId: 'github-desktop', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.github.shifteight.GitHubDesktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GitHub.GitHubDesktop' } },
    tags: ['git', 'github', 'gui']
  },
  {
    id: 'github-cli',
    name: 'GitHub CLI (gh)',
    category: 'Developer Tools',
    description: 'Bring pull requests, issues, actions, and repos to your terminal.',
    publisher: 'GitHub, Inc.',
    website: 'https://cli.github.com/',
    downloadPage: 'https://cli.github.com/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GitHub.cli' },
      macos: { manager: 'brew', packageId: 'gh', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'GitHub.cli' } },
    tags: ['cli', 'github', 'terminal']
  },
  {
    id: 'gitkraken',
    name: 'GitKraken Client',
    category: 'Developer Tools',
    description: 'Visual Git client with interactive rebase, merge conflict resolution, and workspaces.',
    publisher: 'Axosoft, LLC',
    website: 'https://www.gitkraken.com/',
    downloadPage: 'https://www.gitkraken.com/download',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Axosoft.GitKraken' },
      macos: { manager: 'brew', packageId: 'gitkraken', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.axosoft.GitKraken' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Axosoft.GitKraken' } },
    tags: ['git', 'visual', 'commit-graph']
  },
  {
    id: 'nodejs-lts',
    name: 'Node.js (LTS)',
    category: 'Developer Tools',
    description: 'Asynchronous event-driven JavaScript runtime built on Chrome\'s V8 engine.',
    publisher: 'OpenJS Foundation',
    website: 'https://nodejs.org/',
    downloadPage: 'https://nodejs.org/en/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'OpenJS.NodeJS.LTS' },
      macos: { manager: 'brew', packageId: 'node@20', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'OpenJS.NodeJS.LTS' } },
    tags: ['javascript', 'runtime', 'npm', 'backend'],
    featured: true
  },
  {
    id: 'python3',
    name: 'Python 3.12',
    category: 'Developer Tools',
    description: 'High-level, interpreted programming language with vast ecosystem for scripting and AI.',
    publisher: 'Python Software Foundation',
    website: 'https://www.python.org/',
    downloadPage: 'https://www.python.org/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Python.Python.3.12' },
      macos: { manager: 'brew', packageId: 'python@3.12', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Python.Python.3.12' } },
    tags: ['python', 'scripting', 'ai', 'data-science'],
    featured: true
  },
  {
    id: 'uv',
    name: 'uv (Python Package Manager)',
    category: 'Developer Tools',
    description: 'An extremely fast Python package and project manager written in Rust, 10-100x faster than pip.',
    publisher: 'Astral Software',
    website: 'https://astral.sh/uv',
    downloadPage: 'https://github.com/astral-sh/uv/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'astral-sh.uv' },
      macos: { manager: 'brew', packageId: 'uv', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'astral-sh.uv' } },
    tags: ['python', 'pip', 'fast', 'rust']
  },
  {
    id: 'pipx',
    name: 'pipx',
    category: 'Developer Tools',
    description: 'Install and run Python applications in isolated environments.',
    publisher: 'Python Packaging Authority',
    website: 'https://pipx.pypa.io/',
    downloadPage: 'https://pipx.pypa.io/stable/installation/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'pipx.pipx' },
      macos: { manager: 'brew', packageId: 'pipx', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'pipx.pipx' } },
    tags: ['python', 'cli', 'isolation']
  },
  {
    id: 'openjdk-21',
    name: 'Eclipse Temurin JDK 21 (LTS)',
    category: 'Developer Tools',
    description: 'Enterprise-grade, high performance OpenJDK distribution with LTS support.',
    publisher: 'Eclipse Foundation',
    website: 'https://adoptium.net/',
    downloadPage: 'https://adoptium.net/temurin/releases/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'EclipseAdoptium.Temurin.21.JDK' },
      macos: { manager: 'brew', packageId: 'openjdk@21', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'EclipseAdoptium.Temurin.21.JDK' } },
    tags: ['java', 'jdk', 'jvm', 'temurin']
  },
  {
    id: 'dotnet-sdk-8',
    name: '.NET SDK 8.0 (LTS)',
    category: 'Developer Tools',
    description: 'Cross-platform developer platform for building cloud, desktop, and web apps.',
    publisher: 'Microsoft Corporation',
    website: 'https://dotnet.microsoft.com/',
    downloadPage: 'https://dotnet.microsoft.com/download/dotnet/8.0',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.DotNet.SDK.8' },
      macos: { manager: 'brew', packageId: 'dotnet-sdk', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.DotNet.SDK.8' } },
    tags: ['dotnet', 'csharp', 'sdk', 'backend']
  },
  {
    id: 'golang',
    name: 'Go Programming Language',
    category: 'Developer Tools',
    description: 'Open source programming language that makes it easy to build simple, reliable, and efficient software.',
    publisher: 'Google LLC',
    website: 'https://go.dev/',
    downloadPage: 'https://go.dev/dl/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GoLang.Go' },
      macos: { manager: 'brew', packageId: 'go', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'GoLang.Go' } },
    tags: ['golang', 'backend', 'systems']
  },
  {
    id: 'rustup',
    name: 'Rust via rustup',
    category: 'Developer Tools',
    description: 'The official installer and toolchain manager for the Rust programming language.',
    publisher: 'Rust Project Developers',
    website: 'https://rustup.rs/',
    downloadPage: 'https://rustup.rs/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Rustlang.Rustup' },
      macos: { manager: 'brew', packageId: 'rustup-init', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Rustlang.Rustup' } },
    tags: ['rust', 'systems', 'memory-safe', 'cargo']
  },
  {
    id: 'php',
    name: 'PHP',
    category: 'Developer Tools',
    description: 'Popular general-purpose scripting language especially suited to web development.',
    publisher: 'The PHP Group',
    website: 'https://www.php.net/',
    downloadPage: 'https://windows.php.net/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'PHP.PHP' },
      macos: { manager: 'brew', packageId: 'php', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'PHP.PHP' } },
    tags: ['php', 'web', 'backend']
  },
  {
    id: 'ruby',
    name: 'Ruby+Devkit',
    category: 'Developer Tools',
    description: 'Dynamic, open source programming language with a focus on simplicity and productivity.',
    publisher: 'RubyInstaller Team',
    website: 'https://rubyinstaller.org/',
    downloadPage: 'https://rubyinstaller.org/downloads/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RubyInstallerTeam.RubyWithDevKit.3.3' },
      macos: { manager: 'brew', packageId: 'ruby', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'RubyInstallerTeam.RubyWithDevKit.3.3' } },
    tags: ['ruby', 'rails', 'scripting']
  },
  {
    id: 'bun',
    name: 'Bun',
    category: 'Developer Tools',
    description: 'Incredibly fast all-in-one JavaScript runtime, bundler, test runner, and package manager.',
    publisher: 'Oven',
    website: 'https://bun.sh/',
    downloadPage: 'https://bun.sh/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Oven-sh.Bun' },
      macos: { manager: 'brew', packageId: 'oven-sh/bun/bun', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Oven-sh.Bun' } },
    tags: ['javascript', 'typescript', 'fast', 'runtime']
  },
  {
    id: 'deno',
    name: 'Deno',
    category: 'Developer Tools',
    description: 'Next-generation JavaScript and TypeScript runtime built on V8 with secure defaults.',
    publisher: 'Deno Land Inc.',
    website: 'https://deno.com/',
    downloadPage: 'https://deno.com/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'DenoLand.Deno' },
      macos: { manager: 'brew', packageId: 'deno', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'DenoLand.Deno' } },
    tags: ['typescript', 'javascript', 'runtime', 'security']
  },
  {
    id: 'powershell-7',
    name: 'PowerShell 7',
    category: 'Developer Tools',
    description: 'Cross-platform task automation solution consisting of a command-line shell and scripting language.',
    publisher: 'Microsoft Corporation',
    website: 'https://microsoft.com/powershell',
    downloadPage: 'https://github.com/PowerShell/PowerShell/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.PowerShell' },
      macos: { manager: 'brew', packageId: 'powershell', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.PowerShell' } },
    tags: ['terminal', 'powershell', 'scripting', 'automation']
  },
  {
    id: 'windows-terminal',
    name: 'Windows Terminal',
    category: 'Developer Tools',
    description: 'Modern, fast, tabbed terminal application for command-line users with GPU acceleration.',
    publisher: 'Microsoft Corporation',
    website: 'https://github.com/microsoft/terminal',
    downloadPage: 'https://github.com/microsoft/terminal/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.WindowsTerminal' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.WindowsTerminal' } },
    tags: ['terminal', 'console', 'gpu', 'tabs'],
    featured: true
  },
  {
    id: 'alacritty',
    name: 'Alacritty',
    category: 'Developer Tools',
    description: 'Cross-platform, OpenGL-accelerated terminal emulator focused on speed and simplicity.',
    publisher: 'Alacritty Team',
    website: 'https://alacritty.org/',
    downloadPage: 'https://alacritty.org/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Alacritty.Alacritty' },
      macos: { manager: 'brew', packageId: 'alacritty', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.alacritty.Alacritty' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Alacritty.Alacritty' } },
    tags: ['terminal', 'gpu', 'rust', 'fast']
  },
  {
    id: 'wezterm',
    name: 'WezTerm',
    category: 'Developer Tools',
    description: 'GPU-accelerated cross-platform terminal emulator and multiplexer configured via Lua.',
    publisher: 'Wez Furlong',
    website: 'https://wezfurlong.org/wezterm/',
    downloadPage: 'https://wezfurlong.org/wezterm/installation.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Wez.wezterm' },
      macos: { manager: 'brew', packageId: 'wezterm', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.wezfurlong.wezterm' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Wez.wezterm' } },
    tags: ['terminal', 'lua', 'multiplexer']
  },
  {
    id: 'docker-desktop',
    name: 'Docker Desktop',
    category: 'Developer Tools',
    description: 'Seamless way to build, share, and run containerized applications on Windows and Mac.',
    publisher: 'Docker Inc.',
    website: 'https://www.docker.com/products/docker-desktop/',
    downloadPage: 'https://www.docker.com/products/docker-desktop/',
    license: 'Freemium',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Docker.DockerDesktop' },
      macos: { manager: 'brew', packageId: 'docker', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Docker.DockerDesktop' } },
    tags: ['containers', 'docker', 'devops', 'kubernetes'],
    featured: true
  },
  {
    id: 'podman',
    name: 'Podman CLI',
    category: 'Developer Tools',
    description: 'Daemonless, open source container engine for developing, managing, and running OCI containers.',
    publisher: 'Red Hat',
    website: 'https://podman.io/',
    downloadPage: 'https://podman.io/docs/installation',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RedHat.Podman' },
      macos: { manager: 'brew', packageId: 'podman', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'RedHat.Podman' } },
    tags: ['containers', 'daemonless', 'oci', 'rootless']
  },
  {
    id: 'kubectl',
    name: 'Kubernetes CLI (kubectl)',
    category: 'Developer Tools',
    description: 'Command line tool for controlling Kubernetes clusters.',
    publisher: 'Cloud Native Computing Foundation',
    website: 'https://kubernetes.io/docs/reference/kubectl/',
    downloadPage: 'https://kubernetes.io/docs/tasks/tools/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Kubernetes.kubectl' },
      macos: { manager: 'brew', packageId: 'kubernetes-cli', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Kubernetes.kubectl' } },
    tags: ['kubernetes', 'k8s', 'cloud-native', 'devops']
  },
  {
    id: 'helm',
    name: 'Helm',
    category: 'Developer Tools',
    description: 'The package manager for Kubernetes to define, install, and upgrade complex Kubernetes apps.',
    publisher: 'Cloud Native Computing Foundation',
    website: 'https://helm.sh/',
    downloadPage: 'https://helm.sh/docs/intro/install/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Helm.Helm' },
      macos: { manager: 'brew', packageId: 'helm', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Helm.Helm' } },
    tags: ['kubernetes', 'helm', 'charts']
  },
  {
    id: 'postman',
    name: 'Postman',
    category: 'Developer Tools',
    description: 'API platform for building and using APIs, simplifying each step of the API lifecycle.',
    publisher: 'Postman, Inc.',
    website: 'https://www.postman.com/',
    downloadPage: 'https://www.postman.com/downloads/',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Postman.Postman' },
      macos: { manager: 'brew', packageId: 'postman', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.getpostman.Postman' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Postman.Postman' } },
    tags: ['api', 'rest', 'graphql', 'http'],
    featured: true
  },
  {
    id: 'insomnia',
    name: 'Insomnia REST Client',
    category: 'Developer Tools',
    description: 'Streamlined open source API design and testing client for GraphQL, REST, WebSockets, and gRPC.',
    publisher: 'Kong Inc.',
    website: 'https://insomnia.rest/',
    downloadPage: 'https://insomnia.rest/download',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Kong.Insomnia' },
      macos: { manager: 'brew', packageId: 'insomnia', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.insomnia.Rest' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Kong.Insomnia' } },
    tags: ['api', 'rest', 'graphql', 'grpc']
  },
  {
    id: 'bruno',
    name: 'Bruno API Client',
    category: 'Developer Tools',
    description: 'Fast and git-friendly open source API client storing collections directly in local folders.',
    publisher: 'Usebruno',
    website: 'https://www.usebruno.com/',
    downloadPage: 'https://www.usebruno.com/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Usebruno.Bruno' },
      macos: { manager: 'brew', packageId: 'bruno', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.usebruno.Bruno' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Usebruno.Bruno' } },
    tags: ['api', 'git-friendly', 'offline', 'privacy']
  },
  {
    id: 'dbeaver',
    name: 'DBeaver Community',
    category: 'Developer Tools',
    description: 'Free multi-platform universal database tool for developers, SQL programmers, and DBAs.',
    publisher: 'DBeaver Corp',
    website: 'https://dbeaver.io/',
    downloadPage: 'https://dbeaver.io/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'dbeaver.dbeaver' },
      macos: { manager: 'brew', packageId: 'dbeaver-community', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.dbeaver.DBeaverCommunity' }
    },
    detection: { windows: { type: 'winget', checkValue: 'dbeaver.dbeaver' } },
    tags: ['database', 'sql', 'postgres', 'mysql', 'sqlite'],
    featured: true
  },
  {
    id: 'sqlitebrowser',
    name: 'DB Browser for SQLite',
    category: 'Developer Tools',
    description: 'High quality, visual open-source tool to create, design, and edit SQLite database files.',
    publisher: 'DB Browser for SQLite Team',
    website: 'https://sqlitebrowser.org/',
    downloadPage: 'https://sqlitebrowser.org/dl/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'DBBrowserForSQLite.DBBrowserForSQLite' },
      macos: { manager: 'brew', packageId: 'sqlitebrowser', cask: true },
      linux: { manager: 'flatpak', packageId: 'net.sqlitebrowser.sqlitebrowser' }
    },
    detection: { windows: { type: 'winget', checkValue: 'DBBrowserForSQLite.DBBrowserForSQLite' } },
    tags: ['sqlite', 'database', 'gui']
  },
  {
    id: 'mysql-workbench',
    name: 'MySQL Workbench',
    category: 'Developer Tools',
    description: 'Visual database design, SQL development, administration, and database migration tool.',
    publisher: 'Oracle Corporation',
    website: 'https://www.mysql.com/products/workbench/',
    downloadPage: 'https://dev.mysql.com/downloads/workbench/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Oracle.MySQLWorkbench' },
      macos: { manager: 'brew', packageId: 'mysql-workbench', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Oracle.MySQLWorkbench' } },
    tags: ['mysql', 'database', 'oracle']
  },
  {
    id: 'pgadmin',
    name: 'pgAdmin 4',
    category: 'Developer Tools',
    description: 'Comprehensive administration and management tool for the PostgreSQL database.',
    publisher: 'PostgreSQL Global Development Group',
    website: 'https://www.pgadmin.org/',
    downloadPage: 'https://www.pgadmin.org/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'PostgreSQL.pgAdmin' },
      macos: { manager: 'brew', packageId: 'pgadmin4', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.pgadmin.pgadmin4' }
    },
    detection: { windows: { type: 'winget', checkValue: 'PostgreSQL.pgAdmin' } },
    tags: ['postgres', 'postgresql', 'database']
  },
  {
    id: 'android-studio',
    name: 'Android Studio',
    category: 'Developer Tools',
    description: 'Official integrated development environment for Google\'s Android operating system.',
    publisher: 'Google LLC',
    website: 'https://developer.android.com/studio',
    downloadPage: 'https://developer.android.com/studio',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Google.AndroidStudio' },
      macos: { manager: 'brew', packageId: 'android-studio', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.google.AndroidStudio' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Google.AndroidStudio' } },
    tags: ['android', 'kotlin', 'mobile', 'ide']
  },
  {
    id: 'neovim',
    name: 'Neovim',
    category: 'Developer Tools',
    description: 'Vim-fork focused on extensibility, Lua plugins, and modern LSP integration.',
    publisher: 'Neovim Project',
    website: 'https://neovim.io/',
    downloadPage: 'https://neovim.io/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Neovim.Neovim' },
      macos: { manager: 'brew', packageId: 'neovim', cask: false },
      linux: { manager: 'flatpak', packageId: 'io.neovim.nvim' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Neovim.Neovim' } },
    tags: ['editor', 'vim', 'lua', 'terminal'],
    featured: true
  },
  {
    id: 'vim',
    name: 'Vim',
    category: 'Developer Tools',
    description: 'Ubiquitous modal text editor highly configurable for efficient text editing.',
    publisher: 'Bram Moolenaar',
    website: 'https://www.vim.org/',
    downloadPage: 'https://www.vim.org/download.php',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'vim.vim' },
      macos: { manager: 'brew', packageId: 'vim', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'vim.vim' } },
    tags: ['editor', 'modal', 'cli']
  },
  {
    id: 'notepadplusplus',
    name: 'Notepad++',
    category: 'Developer Tools',
    description: 'Free source code editor and Notepad replacement supporting several programming languages.',
    publisher: 'Don Ho',
    website: 'https://notepad-plus-plus.org/',
    downloadPage: 'https://notepad-plus-plus.org/downloads/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'Notepad++.Notepad++' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Notepad++.Notepad++' } },
    tags: ['editor', 'text', 'scintilla', 'lightweight'],
    featured: true
  },
  {
    id: 'sublime-text',
    name: 'Sublime Text 4',
    category: 'Developer Tools',
    description: 'Sophisticated text editor for code, markup, and prose with slick GPU rendering.',
    publisher: 'Sublime HQ Pty Ltd',
    website: 'https://www.sublimetext.com/',
    downloadPage: 'https://www.sublimetext.com/download',
    license: 'Shareware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'SublimeHQ.SublimeText.4' },
      macos: { manager: 'brew', packageId: 'sublime-text', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.sublimetext.three' }
    },
    detection: { windows: { type: 'winget', checkValue: 'SublimeHQ.SublimeText.4' } },
    tags: ['editor', 'fast', 'python']
  },
  {
    id: 'zed',
    name: 'Zed Editor',
    category: 'Developer Tools',
    description: 'High-performance, multiplayer code editor from the creators of Atom and Tree-sitter.',
    publisher: 'Zed Industries',
    website: 'https://zed.dev/',
    downloadPage: 'https://zed.dev/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'ZedIndustries.Zed' },
      macos: { manager: 'brew', packageId: 'zed', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'ZedIndustries.Zed' } },
    tags: ['editor', 'rust', 'collaborative', 'gpu']
  },
  {
    id: 'cursor',
    name: 'Cursor',
    category: 'Developer Tools',
    description: 'AI-first code editor designed for pair-programming with LLMs built on VS Code.',
    publisher: 'Anysphere Inc.',
    website: 'https://www.cursor.com/',
    downloadPage: 'https://www.cursor.com/',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Anysphere.Cursor' },
      macos: { manager: 'brew', packageId: 'cursor', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Anysphere.Cursor' } },
    tags: ['ai', 'copilot', 'editor', 'code']
  },

  // 11. NETWORKING & REMOTE ACCESS (16)
  {
    id: 'wireshark',
    name: 'Wireshark',
    category: 'Networking & Remote Access',
    description: 'The world\'s foremost and widely-used network protocol analyzer.',
    publisher: 'Wireshark Foundation',
    website: 'https://www.wireshark.org/',
    downloadPage: 'https://www.wireshark.org/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'WiresharkFoundation.Wireshark' },
      macos: { manager: 'brew', packageId: 'wireshark', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.wireshark.Wireshark' }
    },
    detection: { windows: { type: 'winget', checkValue: 'WiresharkFoundation.Wireshark' } },
    tags: ['packet-analyzer', 'networking', 'security'],
    featured: true
  },
  {
    id: 'putty',
    name: 'PuTTY',
    category: 'Networking & Remote Access',
    description: 'Free open-source terminal emulator, serial console, and network file transfer client.',
    publisher: 'Simon Tatham',
    website: 'https://www.putty.org/',
    downloadPage: 'https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'SimonTatham.PuTTY' }
    },
    detection: { windows: { type: 'winget', checkValue: 'SimonTatham.PuTTY' } },
    tags: ['ssh', 'telnet', 'serial', 'terminal']
  },
  {
    id: 'filezilla',
    name: 'FileZilla Client',
    category: 'Networking & Remote Access',
    description: 'Free open source cross-platform FTP, FTPS, and SFTP client with intuitive UI.',
    publisher: 'Tim Kosse',
    website: 'https://filezilla-project.org/',
    downloadPage: 'https://filezilla-project.org/download.php?type=client',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'TimKosse.FileZilla.Client' },
      macos: { manager: 'brew', packageId: 'filezilla', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.filezilla.FileZilla' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TimKosse.FileZilla.Client' } },
    tags: ['ftp', 'sftp', 'transfer', 'files']
  },
  {
    id: 'winscp',
    name: 'WinSCP',
    category: 'Networking & Remote Access',
    description: 'Popular SFTP client and FTP client for Windows for secure file copy.',
    publisher: 'Martin Přikryl',
    website: 'https://winscp.net/',
    downloadPage: 'https://winscp.net/eng/download.php',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'WinSCP.WinSCP' }
    },
    detection: { windows: { type: 'winget', checkValue: 'WinSCP.WinSCP' } },
    tags: ['sftp', 'scp', 'ftp', 'ssh']
  },
  {
    id: 'rustdesk',
    name: 'RustDesk',
    category: 'Networking & Remote Access',
    description: 'Full-featured open source remote control alternative to TeamViewer with self-hosting.',
    publisher: 'RustDesk Team',
    website: 'https://rustdesk.com/',
    downloadPage: 'https://rustdesk.com/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RustDesk.RustDesk' },
      macos: { manager: 'brew', packageId: 'rustdesk', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.rustdesk.RustDesk' }
    },
    detection: { windows: { type: 'winget', checkValue: 'RustDesk.RustDesk' } },
    tags: ['remote-desktop', 'rust', 'open-source'],
    featured: true
  },
  {
    id: 'anydesk',
    name: 'AnyDesk',
    category: 'Networking & Remote Access',
    description: 'High-speed remote desktop software with low latency even at high screen resolutions.',
    publisher: 'AnyDesk Software GmbH',
    website: 'https://anydesk.com/',
    downloadPage: 'https://anydesk.com/en/downloads',
    license: 'Freemium',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'AnyDeskSoftwareGmbH.AnyDesk' },
      macos: { manager: 'brew', packageId: 'anydesk', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.anydesk.AnyDesk' }
    },
    detection: { windows: { type: 'winget', checkValue: 'AnyDeskSoftwareGmbH.AnyDesk' } },
    tags: ['remote-access', 'desktop', 'support']
  },
  {
    id: 'teamviewer',
    name: 'TeamViewer',
    category: 'Networking & Remote Access',
    description: 'Remote connectivity platform to access, control, and repair devices from anywhere.',
    publisher: 'TeamViewer Germany GmbH',
    website: 'https://www.teamviewer.com/',
    downloadPage: 'https://www.teamviewer.com/en/download/',
    license: 'Freemium',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'TeamViewer.TeamViewer' },
      macos: { manager: 'brew', packageId: 'teamviewer', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.teamviewer.TeamViewer' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TeamViewer.TeamViewer' } },
    tags: ['remote-control', 'support', 'enterprise']
  },
  {
    id: 'tailscale',
    name: 'Tailscale',
    category: 'Networking & Remote Access',
    description: 'Zero-config WireGuard mesh VPN that makes devices easily and securely accessible anywhere.',
    publisher: 'Tailscale Inc.',
    website: 'https://tailscale.com/',
    downloadPage: 'https://tailscale.com/download',
    license: 'Freemium',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Tailscale.Tailscale' },
      macos: { manager: 'brew', packageId: 'tailscale', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.tailscale.Tailscale' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Tailscale.Tailscale' } },
    tags: ['vpn', 'mesh', 'wireguard', 'networking'],
    featured: true
  },
  {
    id: 'wireguard',
    name: 'WireGuard',
    category: 'Networking & Remote Access',
    description: 'Extremely simple yet fast and modern VPN utilizing state-of-the-art cryptography.',
    publisher: 'Jason A. Donenfeld',
    website: 'https://www.wireguard.com/',
    downloadPage: 'https://www.wireguard.com/install/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'WireGuard.WireGuard' },
      macos: { manager: 'brew', packageId: 'wireguard-tools', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'WireGuard.WireGuard' } },
    tags: ['vpn', 'tunnel', 'crypto', 'fast']
  },
  {
    id: 'openvpn-connect',
    name: 'OpenVPN Connect',
    category: 'Networking & Remote Access',
    description: 'Official full-featured OpenVPN client for private tunnels and corporate networks.',
    publisher: 'OpenVPN Inc.',
    website: 'https://openvpn.net/',
    downloadPage: 'https://openvpn.net/client-connect-vpn-for-windows/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'OpenVPNTechnologies.OpenVPNConnect' },
      macos: { manager: 'brew', packageId: 'openvpn-connect', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'OpenVPNTechnologies.OpenVPNConnect' } },
    tags: ['vpn', 'openvpn', 'corporate']
  },
  {
    id: 'cloudflare-warp',
    name: 'Cloudflare WARP',
    category: 'Networking & Remote Access',
    description: 'Replace the connection between your device and the Internet with a modern, optimized protocol.',
    publisher: 'Cloudflare Inc.',
    website: 'https://1.1.1.1/',
    downloadPage: 'https://1.1.1.1/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Cloudflare.Warp' },
      macos: { manager: 'brew', packageId: 'cloudflare-warp', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Cloudflare.Warp' } },
    tags: ['dns', 'warp', 'cloudflare', '1.1.1.1']
  },
  {
    id: 'mremoteng',
    name: 'mRemoteNG',
    category: 'Networking & Remote Access',
    description: 'Multi-tab remote connections manager supporting RDP, VNC, SSH, Telnet, and HTTP.',
    publisher: 'mRemoteNG Team',
    website: 'https://mremoteng.org/',
    downloadPage: 'https://mremoteng.org/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'mRemoteNG.mRemoteNG' }
    },
    detection: { windows: { type: 'winget', checkValue: 'mRemoteNG.mRemoteNG' } },
    tags: ['rdp', 'ssh', 'vnc', 'tabbed']
  },
  {
    id: 'iperf3',
    name: 'iperf3',
    category: 'Networking & Remote Access',
    description: 'Tool for active measurements of the maximum achievable bandwidth on IP networks.',
    publisher: 'ESnet / Lawrence Berkeley National Laboratory',
    website: 'https://software.es.net/iperf/',
    downloadPage: 'https://software.es.net/iperf/obtaining.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'iperf3.iperf3' },
      macos: { manager: 'brew', packageId: 'iperf3', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'iperf3.iperf3' } },
    tags: ['bandwidth', 'throughput', 'network-speed', 'cli']
  },
  {
    id: 'nmap',
    name: 'Nmap & Zenmap',
    category: 'Networking & Remote Access',
    description: 'Free and open source utility for network discovery and security auditing.',
    publisher: 'Gordon Lyon (Fyodor)',
    website: 'https://nmap.org/',
    downloadPage: 'https://nmap.org/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Insecure.Nmap' },
      macos: { manager: 'brew', packageId: 'nmap', cask: false },
      linux: { manager: 'flatpak', packageId: 'org.nmap.Zenmap' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Insecure.Nmap' } },
    tags: ['port-scanner', 'security', 'auditing']
  },
  {
    id: 'tightvnc',
    name: 'TightVNC',
    category: 'Networking & Remote Access',
    description: 'Free remote control software package allowing you to see and control the desktop of a remote machine.',
    publisher: 'GlavSoft LLC',
    website: 'https://www.tightvnc.com/',
    downloadPage: 'https://www.tightvnc.com/download.php',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'TightVNC.TightVNC' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TightVNC.TightVNC' } },
    tags: ['vnc', 'remote-control', 'classic']
  },
  {
    id: 'realvnc-viewer',
    name: 'RealVNC Viewer',
    category: 'Networking & Remote Access',
    description: 'Remote desktop client to connect to computers running VNC Connect around the world.',
    publisher: 'RealVNC Limited',
    website: 'https://www.realvnc.com/',
    downloadPage: 'https://www.realvnc.com/en/connect/download/viewer/',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RealVNC.VNCViewer' },
      macos: { manager: 'brew', packageId: 'realvnc-vnc-viewer', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'RealVNC.VNCViewer' } },
    tags: ['vnc', 'remote-viewer']
  },

  // 12. SYSTEM UTILITIES (18)
  {
    id: 'powertoys',
    name: 'Microsoft PowerToys',
    category: 'System Utilities',
    description: 'Set of utilities for power users to tune and streamline their Windows experience for greater productivity.',
    publisher: 'Microsoft Corporation',
    website: 'https://github.com/microsoft/PowerToys',
    downloadPage: 'https://github.com/microsoft/PowerToys/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.PowerToys' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.PowerToys' } },
    tags: ['fancyzones', 'powertoys-run', 'ocr', 'colorpicker'],
    featured: true
  },
  {
    id: 'autohotkey',
    name: 'AutoHotkey v2',
    category: 'System Utilities',
    description: 'Powerful scripting language for desktop automation, custom hotkeys, and macro shortcuts.',
    publisher: 'AutoHotkey Foundation LLC',
    website: 'https://www.autohotkey.com/',
    downloadPage: 'https://www.autohotkey.com/download/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'AutoHotkey.AutoHotkey' }
    },
    detection: { windows: { type: 'winget', checkValue: 'AutoHotkey.AutoHotkey' } },
    tags: ['macros', 'hotkeys', 'automation', 'scripting'],
    featured: true
  },
  {
    id: 'hwinfo',
    name: 'HWiNFO',
    category: 'System Utilities',
    description: 'Comprehensive hardware analysis, monitoring, and reporting for Windows.',
    publisher: 'REALiX',
    website: 'https://www.hwinfo.com/',
    downloadPage: 'https://www.hwinfo.com/download/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'REALiX.HWiNFO' }
    },
    detection: { windows: { type: 'winget', checkValue: 'REALiX.HWiNFO' } },
    tags: ['hardware', 'sensors', 'monitoring', 'diagnostics']
  },
  {
    id: 'cpuz',
    name: 'CPU-Z',
    category: 'System Utilities',
    description: 'System profiling software gathering info on the CPU, cache, motherboard, and RAM.',
    publisher: 'CPUID',
    website: 'https://www.cpuid.com/softwares/cpu-z.html',
    downloadPage: 'https://www.cpuid.com/softwares/cpu-z.html',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'CPUID.CPU-Z' }
    },
    detection: { windows: { type: 'winget', checkValue: 'CPUID.CPU-Z' } },
    tags: ['cpu', 'processor', 'ram', 'specs']
  },
  {
    id: 'gpuz',
    name: 'GPU-Z',
    category: 'System Utilities',
    description: 'Lightweight utility designed to give all information about your video card and GPU.',
    publisher: 'TechPowerUp',
    website: 'https://www.techpowerup.com/gpuz/',
    downloadPage: 'https://www.techpowerup.com/download/techpowerup-gpu-z/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'TechPowerUp.GPU-Z' }
    },
    detection: { windows: { type: 'winget', checkValue: 'TechPowerUp.GPU-Z' } },
    tags: ['gpu', 'graphics', 'nvidia', 'amd']
  },
  {
    id: 'crystaldiskinfo',
    name: 'CrystalDiskInfo',
    category: 'System Utilities',
    description: 'HDD/SSD health monitoring utility supporting S.M.A.R.T. and temperature displays.',
    publisher: 'Crystal Dew World',
    website: 'https://crystalmark.info/en/software/crystaldiskinfo/',
    downloadPage: 'https://crystalmark.info/en/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'CrystalDewWorld.CrystalDiskInfo' }
    },
    detection: { windows: { type: 'winget', checkValue: 'CrystalDewWorld.CrystalDiskInfo' } },
    tags: ['ssd', 'hdd', 'smart', 'health']
  },
  {
    id: 'crystaldiskmark',
    name: 'CrystalDiskMark',
    category: 'System Utilities',
    description: 'Storage benchmarking tool measuring sequential and random read/write speeds.',
    publisher: 'Crystal Dew World',
    website: 'https://crystalmark.info/en/software/crystaldiskmark/',
    downloadPage: 'https://crystalmark.info/en/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'CrystalDewWorld.CrystalDiskMark' }
    },
    detection: { windows: { type: 'winget', checkValue: 'CrystalDewWorld.CrystalDiskMark' } },
    tags: ['benchmark', 'storage', 'speed', 'ssd']
  },
  {
    id: 'fancontrol',
    name: 'Fan Control',
    category: 'System Utilities',
    description: 'Highly customizable fan control software allowing custom curves and sensor mixes.',
    publisher: 'Rem0o',
    website: 'https://getfancontrol.com/',
    downloadPage: 'https://getfancontrol.com/',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Rem0o.FanControl' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Rem0o.FanControl' } },
    tags: ['cooling', 'fans', 'hardware', 'noise']
  },
  {
    id: 'rufus',
    name: 'Rufus',
    category: 'System Utilities',
    description: 'Format and create bootable USB flash drives reliably and quickly.',
    publisher: 'Pete Batard',
    website: 'https://rufus.ie/',
    downloadPage: 'https://rufus.ie/en/#download',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Rufus.Rufus' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Rufus.Rufus' } },
    tags: ['usb', 'bootable', 'iso', 'windows-install'],
    featured: true
  },
  {
    id: 'balena-etcher',
    name: 'balenaEtcher',
    category: 'System Utilities',
    description: 'Flash OS images to SD cards and USB drives, safely and easily.',
    publisher: 'Balena Ltd',
    website: 'https://etcher.balena.io/',
    downloadPage: 'https://etcher.balena.io/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Balena.Etcher' },
      macos: { manager: 'brew', packageId: 'balenaetcher', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.balena.etcher' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Balena.Etcher' } },
    tags: ['flasher', 'sd-card', 'usb', 'iso']
  },
  {
    id: 'raspberry-pi-imager',
    name: 'Raspberry Pi Imager',
    category: 'System Utilities',
    description: 'Quick and easy way to install Raspberry Pi OS and other operating systems to micro-SD.',
    publisher: 'Raspberry Pi Ltd',
    website: 'https://www.raspberrypi.com/software/',
    downloadPage: 'https://www.raspberrypi.com/software/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RaspberryPiFoundation.RaspberryPiImager' },
      macos: { manager: 'brew', packageId: 'raspberry-pi-imager', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.raspberrypi.rpi-imager' }
    },
    detection: { windows: { type: 'winget', checkValue: 'RaspberryPiFoundation.RaspberryPiImager' } },
    tags: ['raspberry-pi', 'sd-card', 'flasher']
  },
  {
    id: 'ventoy',
    name: 'Ventoy',
    category: 'System Utilities',
    description: 'Open-source tool to create bootable USB drives with multiple ISO files directly.',
    publisher: 'ventoy.net',
    website: 'https://www.ventoy.net/',
    downloadPage: 'https://www.ventoy.net/en/download.html',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Ventoy.Ventoy' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Ventoy.Ventoy' } },
    tags: ['multiboot', 'iso', 'usb']
  },
  {
    id: 'localsend',
    name: 'LocalSend',
    category: 'System Utilities',
    description: 'Open source AirDrop alternative to securely share files with nearby devices over Wi-Fi.',
    publisher: 'LocalSend Project',
    website: 'https://localsend.org/',
    downloadPage: 'https://localsend.org/#/download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'LocalSend.LocalSend' },
      macos: { manager: 'brew', packageId: 'localsend', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.localsend.localsend_app' }
    },
    detection: { windows: { type: 'winget', checkValue: 'LocalSend.LocalSend' } },
    tags: ['airdrop', 'wifi', 'file-share', 'cross-platform'],
    featured: true
  },
  {
    id: 'kdeconnect',
    name: 'KDE Connect',
    category: 'System Utilities',
    description: 'Seamless integration between your smartphone and computer (shared clipboard, notifications, media controls).',
    publisher: 'KDE Community',
    website: 'https://kdeconnect.kde.org/',
    downloadPage: 'https://kdeconnect.kde.org/download.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KDE.KDEConnect' },
      macos: { manager: 'brew', packageId: 'kdeconnect', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.kde.kdeconnect' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KDE.KDEConnect' } },
    tags: ['phone-sync', 'notifications', 'clipboard']
  },
  {
    id: 'barrier',
    name: 'Barrier KVM',
    category: 'System Utilities',
    description: 'Software KVM switch to share one mouse and keyboard across multiple computers.',
    publisher: 'Debauchee Open Source',
    website: 'https://github.com/debauchee/barrier',
    downloadPage: 'https://github.com/debauchee/barrier/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Debauchee.Barrier' },
      macos: { manager: 'brew', packageId: 'barrier', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.github.debauchee.barrier' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Debauchee.Barrier' } },
    tags: ['kvm', 'mouse-sharing', 'keyboard']
  },
  {
    id: 'inputleap',
    name: 'Input Leap',
    category: 'System Utilities',
    description: 'Successor to Barrier KVM enabling mouse and keyboard sharing across multiple monitors and OSes.',
    publisher: 'Input Leap Community',
    website: 'https://github.com/input-leap/input-leap',
    downloadPage: 'https://github.com/input-leap/input-leap/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'InputLeap.InputLeap' },
      macos: { manager: 'brew', packageId: 'input-leap', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.github.input_leap.InputLeap' }
    },
    detection: { windows: { type: 'winget', checkValue: 'InputLeap.InputLeap' } },
    tags: ['kvm', 'mouse-sharing', 'input-leap']
  },
  {
    id: 'bleachbit',
    name: 'BleachBit',
    category: 'System Utilities',
    description: 'Free cache cleaner that clears disk space and guards privacy by wiping temporary junk files.',
    publisher: 'Andrew Ziem',
    website: 'https://www.bleachbit.org/',
    downloadPage: 'https://www.bleachbit.org/download',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'BleachBit.BleachBit' },
      linux: { manager: 'flatpak', packageId: 'org.bleachbit.BleachBit' }
    },
    detection: { windows: { type: 'winget', checkValue: 'BleachBit.BleachBit' } },
    tags: ['cleaner', 'privacy', 'cache']
  },
  {
    id: 'geekbench',
    name: 'Geekbench 6',
    category: 'System Utilities',
    description: 'Cross-platform benchmark measuring processor and graphics card compute power.',
    publisher: 'Primate Labs Inc.',
    website: 'https://www.geekbench.com/',
    downloadPage: 'https://www.geekbench.com/download/',
    license: 'Freemium',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'PrimateLabs.Geekbench.6' },
      macos: { manager: 'brew', packageId: 'geekbench', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'PrimateLabs.Geekbench.6' } },
    tags: ['benchmark', 'cpu', 'gpu', 'speed']
  },

  // 13. VIRTUALIZATION & CONTAINERS (8)
  {
    id: 'virtualbox',
    name: 'Oracle VM VirtualBox',
    category: 'Virtualization & Containers',
    description: 'Powerful x86 and AMD64/Intel64 virtualization software for enterprise and home use.',
    publisher: 'Oracle Corporation',
    website: 'https://www.virtualbox.org/',
    downloadPage: 'https://www.virtualbox.org/wiki/Downloads',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Oracle.VirtualBox' },
      macos: { manager: 'brew', packageId: 'virtualbox', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Oracle.VirtualBox' } },
    tags: ['vm', 'virtualization', 'hypervisor'],
    featured: true
  },
  {
    id: 'vmware-workstation',
    name: 'VMware Workstation Pro',
    category: 'Virtualization & Containers',
    description: 'Industry standard for running multiple virtual machines on Windows and Linux PCs (now free for personal use).',
    publisher: 'Broadcom Inc.',
    website: 'https://www.vmware.com/products/desktop-hypervisor/workstation-and-fusion',
    downloadPage: 'https://www.vmware.com/products/desktop-hypervisor/workstation-and-fusion',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'VMware.WorkstationPro' }
    },
    detection: { windows: { type: 'winget', checkValue: 'VMware.WorkstationPro' } },
    tags: ['vmware', 'hypervisor', 'virtual-machine']
  },
  {
    id: 'qemu',
    name: 'QEMU',
    category: 'Virtualization & Containers',
    description: 'Generic and open source machine emulator and virtualizer supporting multiple architectures.',
    publisher: 'Software Freedom Conservancy',
    website: 'https://www.qemu.org/',
    downloadPage: 'https://www.qemu.org/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'SoftwareFreedomConservancy.QEMU' },
      macos: { manager: 'brew', packageId: 'qemu', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'SoftwareFreedomConservancy.QEMU' } },
    tags: ['emulator', 'kvm', 'virtualization']
  },
  {
    id: 'utm',
    name: 'UTM Virtual Machines',
    category: 'Virtualization & Containers',
    description: 'Full featured system emulator and virtual machine host for macOS built on QEMU.',
    publisher: 'UTM Project',
    website: 'https://mac.getutm.app/',
    downloadPage: 'https://mac.getutm.app/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['macos'],
    architectures: ['x64', 'arm64'],
    packages: {
      macos: { manager: 'brew', packageId: 'utm', cask: true }
    },
    detection: {},
    tags: ['macos', 'arm', 'apple-silicon', 'virtualization']
  },
  {
    id: 'podman-desktop',
    name: 'Podman Desktop',
    category: 'Virtualization & Containers',
    description: 'Best open source GUI for containers and Kubernetes with seamless Podman integration.',
    publisher: 'Red Hat',
    website: 'https://podman-desktop.io/',
    downloadPage: 'https://podman-desktop.io/downloads',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'RedHat.Podman-Desktop' },
      macos: { manager: 'brew', packageId: 'podman-desktop', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.podman_desktop.PodmanDesktop' }
    },
    detection: { windows: { type: 'winget', checkValue: 'RedHat.Podman-Desktop' } },
    tags: ['containers', 'gui', 'podman', 'kubernetes']
  },
  {
    id: 'multipass',
    name: 'Multipass',
    category: 'Virtualization & Containers',
    description: 'Orchestrate Ubuntu instances in seconds across Windows, Mac, and Linux.',
    publisher: 'Canonical Ltd.',
    website: 'https://multipass.run/',
    downloadPage: 'https://multipass.run/install',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Canonical.Multipass' },
      macos: { manager: 'brew', packageId: 'multipass', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Canonical.Multipass' } },
    tags: ['ubuntu', 'cloud-init', 'vms']
  },
  {
    id: 'vagrant',
    name: 'Vagrant',
    category: 'Virtualization & Containers',
    description: 'Tool for building and managing virtual machine environments in a single reproducible workflow.',
    publisher: 'HashiCorp',
    website: 'https://www.vagrantup.com/',
    downloadPage: 'https://developer.hashicorp.com/vagrant/install',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Hashicorp.Vagrant' },
      macos: { manager: 'brew', packageId: 'vagrant', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Hashicorp.Vagrant' } },
    tags: ['devops', 'iac', 'virtual-machine']
  },
  {
    id: 'terraform',
    name: 'Terraform',
    category: 'Virtualization & Containers',
    description: 'Infrastructure as code software tool providing a consistent CLI workflow to manage cloud services.',
    publisher: 'HashiCorp',
    website: 'https://www.terraform.io/',
    downloadPage: 'https://developer.hashicorp.com/terraform/install',
    license: 'BSL',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Hashicorp.Terraform' },
      macos: { manager: 'brew', packageId: 'terraform', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'Hashicorp.Terraform' } },
    tags: ['iac', 'cloud', 'devops', 'hashicorp']
  },

  // 14. 3D, CAD & 3D PRINTING (10)
  {
    id: 'freecad',
    name: 'FreeCAD',
    category: '3D, CAD & 3D Printing',
    description: 'General purpose feature-based parametric 3D modeler for mechanical engineering and product design.',
    publisher: 'FreeCAD Community',
    website: 'https://www.freecad.org/',
    downloadPage: 'https://www.freecad.org/downloads.php',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'FreeCAD.FreeCAD' },
      macos: { manager: 'brew', packageId: 'freecad', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.freecadweb.FreeCAD' }
    },
    detection: { windows: { type: 'winget', checkValue: 'FreeCAD.FreeCAD' } },
    tags: ['cad', 'parametric', 'engineering', '3d'],
    featured: true
  },
  {
    id: 'openscad',
    name: 'OpenSCAD',
    category: '3D, CAD & 3D Printing',
    description: 'Programmer-oriented solid 3D CAD modeler focused on CSG (Constructive Solid Geometry).',
    publisher: 'OpenSCAD Project',
    website: 'https://openscad.org/',
    downloadPage: 'https://openscad.org/downloads.html',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'OpenSCAD.OpenSCAD' },
      macos: { manager: 'brew', packageId: 'openscad', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.openscad.OpenSCAD' }
    },
    detection: { windows: { type: 'winget', checkValue: 'OpenSCAD.OpenSCAD' } },
    tags: ['code-cad', '3d-printing', 'parametric']
  },
  {
    id: 'prusaslicer',
    name: 'PrusaSlicer',
    category: '3D, CAD & 3D Printing',
    description: 'Powerful open-source tool to convert 3D models into G-code instructions for 3D printers.',
    publisher: 'Prusa Research',
    website: 'https://www.prusa3d.com/page/prusaslicer_424/',
    downloadPage: 'https://www.prusa3d.com/drivers/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Prusa3D.PrusaSlicer' },
      macos: { manager: 'brew', packageId: 'prusaslicer', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.prusa3d.PrusaSlicer' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Prusa3D.PrusaSlicer' } },
    tags: ['slicer', '3d-printing', 'gcode', 'prusa'],
    featured: true
  },
  {
    id: 'orcaslicer',
    name: 'OrcaSlicer',
    category: '3D, CAD & 3D Printing',
    description: 'Feature-packed open-source 3D slicer for Bambu, Voron, and Creality printers with direct calibration.',
    publisher: 'SoftFever',
    website: 'https://github.com/SoftFever/OrcaSlicer',
    downloadPage: 'https://github.com/SoftFever/OrcaSlicer/releases',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'SoftFever.OrcaSlicer' },
      macos: { manager: 'brew', packageId: 'orcaslicer', cask: true },
      linux: { manager: 'flatpak', packageId: 'io.github.SoftFever.OrcaSlicer' }
    },
    detection: { windows: { type: 'winget', checkValue: 'SoftFever.OrcaSlicer' } },
    tags: ['slicer', 'bambu', 'voron', 'calibration']
  },
  {
    id: 'ultimaker-cura',
    name: 'UltiMaker Cura',
    category: '3D, CAD & 3D Printing',
    description: 'Trusted 3D printing slicing software used by millions with support for 500+ printers.',
    publisher: 'UltiMaker B.V.',
    website: 'https://ultimaker.com/software/ultimaker-cura/',
    downloadPage: 'https://ultimaker.com/software/ultimaker-cura/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'UltiMaker.Cura' },
      macos: { manager: 'brew', packageId: 'ultimaker-cura', cask: true },
      linux: { manager: 'flatpak', packageId: 'nl.ultimaker.cura' }
    },
    detection: { windows: { type: 'winget', checkValue: 'UltiMaker.Cura' } },
    tags: ['slicer', '3d-printing', 'cura']
  },
  {
    id: 'bambu-studio',
    name: 'Bambu Studio',
    category: '3D, CAD & 3D Printing',
    description: 'All-in-one cutting-edge 3D printing software for Bambu Lab printers.',
    publisher: 'Bambu Lab',
    website: 'https://bambulab.com/en/download/studio',
    downloadPage: 'https://bambulab.com/en/download/studio',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'BambuLab.BambuStudio' },
      macos: { manager: 'brew', packageId: 'bambu-studio', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.bambulab.BambuStudio' }
    },
    detection: { windows: { type: 'winget', checkValue: 'BambuLab.BambuStudio' } },
    tags: ['bambu-lab', 'slicer', 'ams', 'multi-color']
  },
  {
    id: 'kicad',
    name: 'KiCad EDA',
    category: '3D, CAD & 3D Printing',
    description: 'Open source schematic capture and PCB layout CAD software with 3D raytracing viewer.',
    publisher: 'KiCad Development Team',
    website: 'https://www.kicad.org/',
    downloadPage: 'https://www.kicad.org/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'KiCad.KiCad' },
      macos: { manager: 'brew', packageId: 'kicad', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.kicad.KiCad' }
    },
    detection: { windows: { type: 'winget', checkValue: 'KiCad.KiCad' } },
    tags: ['eda', 'pcb', 'schematics', 'electronics']
  },
  {
    id: 'meshlab',
    name: 'MeshLab',
    category: '3D, CAD & 3D Printing',
    description: 'Open source system for processing and editing 3D triangular meshes and point clouds.',
    publisher: 'Visual Computing Lab - ISTI - CNR',
    website: 'https://www.meshlab.net/',
    downloadPage: 'https://www.meshlab.net/#download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'MeshLab.MeshLab' },
      macos: { manager: 'brew', packageId: 'meshlab', cask: true },
      linux: { manager: 'flatpak', packageId: 'net.meshlab.MeshLab' }
    },
    detection: { windows: { type: 'winget', checkValue: 'MeshLab.MeshLab' } },
    tags: ['mesh', 'point-cloud', '3d-cleanup']
  },
  {
    id: 'solvespace',
    name: 'SolveSpace',
    category: '3D, CAD & 3D Printing',
    description: 'Parametric 2d/3d CAD program with constraint solver, minimal footprint, and STEP export.',
    publisher: 'SolveSpace Community',
    website: 'https://solvespace.com/',
    downloadPage: 'https://solvespace.com/download.pl',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'SolveSpace.SolveSpace' },
      macos: { manager: 'brew', packageId: 'solvespace', cask: true },
      linux: { manager: 'flatpak', packageId: 'com.solvespace.SolveSpace' }
    },
    detection: { windows: { type: 'winget', checkValue: 'SolveSpace.SolveSpace' } },
    tags: ['cad', 'constraint-solver', 'lightweight']
  },
  {
    id: 'wings3d',
    name: 'Wings 3D',
    category: '3D, CAD & 3D Printing',
    description: 'Advanced sub-division modeler that is both powerful and easy to use.',
    publisher: 'Wings 3D Community',
    website: 'http://www.wings3d.com/',
    downloadPage: 'http://www.wings3d.com/?page_id=84',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Wings3D.Wings3D' },
      macos: { manager: 'brew', packageId: 'wings3d', cask: true }
    },
    detection: { windows: { type: 'winget', checkValue: 'Wings3D.Wings3D' } },
    tags: ['subdivision', 'modeling', 'polygonal']
  },

  // 15. EDUCATION & ACCESSIBILITY (10)
  {
    id: 'anki',
    name: 'Anki',
    category: 'Education & Accessibility',
    description: 'Powerful, intelligent flash cards using spaced repetition to remember anything forever.',
    publisher: 'Anki Project',
    website: 'https://apps.ankiweb.net/',
    downloadPage: 'https://apps.ankiweb.net/#download',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Anki.Anki' },
      macos: { manager: 'brew', packageId: 'anki', cask: true },
      linux: { manager: 'flatpak', packageId: 'net.ankiweb.Anki' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Anki.Anki' } },
    tags: ['flashcards', 'study', 'spaced-repetition', 'learning'],
    featured: true
  },
  {
    id: 'nvda',
    name: 'NVDA Screen Reader',
    category: 'Education & Accessibility',
    description: 'NonVisual Desktop Access: free, high-quality screen reader for blind and vision-impaired users.',
    publisher: 'NV Access Limited',
    website: 'https://www.nvaccess.org/',
    downloadPage: 'https://www.nvaccess.org/download/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'NVAccess.NVDA' }
    },
    detection: { windows: { type: 'winget', checkValue: 'NVAccess.NVDA' } },
    tags: ['accessibility', 'screen-reader', 'blind', 'speech'],
    featured: true
  },
  {
    id: 'orca-screenreader',
    name: 'Orca Screen Reader',
    category: 'Education & Accessibility',
    description: 'Flexible and extensible screen reader that provides access to the graphical desktop on Linux.',
    publisher: 'GNOME Project',
    website: 'https://wiki.gnome.org/Projects/Orca',
    downloadPage: 'https://wiki.gnome.org/Projects/Orca',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      linux: { manager: 'apt', packageId: 'gnome-orca' }
    },
    detection: {},
    tags: ['accessibility', 'gnome', 'screen-reader']
  },
  {
    id: 'goldendict',
    name: 'GoldenDict',
    category: 'Education & Accessibility',
    description: 'Feature-rich dictionary lookup program supporting Babylon, StarDict, and Wikipedia.',
    publisher: 'GoldenDict Team',
    website: 'http://goldendict.org/',
    downloadPage: 'http://goldendict.org/download.php',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GoldenDict.GoldenDict' },
      macos: { manager: 'brew', packageId: 'goldendict', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.goldendict.GoldenDict' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GoldenDict.GoldenDict' } },
    tags: ['dictionary', 'lookup', 'vocabulary']
  },
  {
    id: 'tesseract-ocr',
    name: 'Tesseract OCR',
    category: 'Education & Accessibility',
    description: 'Leading open source optical character recognition engine recognizing text in 100+ languages.',
    publisher: 'Mannheim University Library / Google',
    website: 'https://github.com/tesseract-ocr/tesseract',
    downloadPage: 'https://github.com/UB-Mannheim/tesseract/wiki',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'UB-Mannheim.TesseractOCR' },
      macos: { manager: 'brew', packageId: 'tesseract', cask: false }
    },
    detection: { windows: { type: 'winget', checkValue: 'UB-Mannheim.TesseractOCR' } },
    tags: ['ocr', 'text-recognition', 'cli']
  },
  {
    id: 'geogebra',
    name: 'GeoGebra Classic',
    category: 'Education & Accessibility',
    description: 'Dynamic mathematics software for all levels of education: geometry, algebra, spreadsheets, graphing.',
    publisher: 'International GeoGebra Institute',
    website: 'https://www.geogebra.org/',
    downloadPage: 'https://www.geogebra.org/download',
    license: 'Freeware',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GeoGebra.GeoGebra' },
      macos: { manager: 'brew', packageId: 'geogebra', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.geogebra.GeoGebra' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GeoGebra.GeoGebra' } },
    tags: ['math', 'geometry', 'calculus', 'education']
  },
  {
    id: 'stellarium',
    name: 'Stellarium Planetarium',
    category: 'Education & Accessibility',
    description: 'Realistic 3D planetarium showing a photorealistic night sky with stars, constellations, and planets.',
    publisher: 'Stellarium Team',
    website: 'https://stellarium.org/',
    downloadPage: 'https://stellarium.org/',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Stellarium.Stellarium' },
      macos: { manager: 'brew', packageId: 'stellarium', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.stellarium.Stellarium' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Stellarium.Stellarium' } },
    tags: ['astronomy', 'stars', 'planetarium', 'science']
  },
  {
    id: 'scilab',
    name: 'Scilab',
    category: 'Education & Accessibility',
    description: 'Open source software for numerical computation providing a powerful computing environment.',
    publisher: 'Dassault Systèmes',
    website: 'https://www.scilab.org/',
    downloadPage: 'https://www.scilab.org/download',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Scilab.Scilab' },
      macos: { manager: 'brew', packageId: 'scilab', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.scilab.Scilab' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Scilab.Scilab' } },
    tags: ['math', 'matlab-alternative', 'engineering']
  },
  {
    id: 'gnucash',
    name: 'GnuCash',
    category: 'Education & Accessibility',
    description: 'Personal and small-business financial-accounting software with double-entry bookkeeping.',
    publisher: 'GnuCash Development Team',
    website: 'https://www.gnucash.org/',
    downloadPage: 'https://www.gnucash.org/download.phtml',
    license: 'Open Source',
    requiresAdmin: false,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'GnuCash.GnuCash' },
      macos: { manager: 'brew', packageId: 'gnucash', cask: true },
      linux: { manager: 'flatpak', packageId: 'org.gnucash.GnuCash' }
    },
    detection: { windows: { type: 'winget', checkValue: 'GnuCash.GnuCash' } },
    tags: ['accounting', 'finance', 'bookkeeping']
  },
  {
    id: 'scribus',
    name: 'Scribus',
    category: 'Education & Accessibility',
    description: 'Open source desktop publishing software for creating magazines, posters, and books.',
    publisher: 'Scribus Team',
    website: 'https://www.scribus.net/',
    downloadPage: 'https://www.scribus.net/downloads/',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Scribus.Scribus' },
      macos: { manager: 'brew', packageId: 'scribus', cask: true },
      linux: { manager: 'flatpak', packageId: 'net.scribus.Scribus' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Scribus.Scribus' } },
    tags: ['publishing', 'layout', 'indesign-alternative']
  },

  // 16. RUNTIMES & DEPENDENCIES (8)
  {
    id: 'vcredist-2015-2022',
    name: 'Microsoft Visual C++ 2015-2022 Redistributable (x64)',
    category: 'Runtimes & Dependencies',
    description: 'Runtime components required to run C++ applications developed with Visual Studio.',
    publisher: 'Microsoft Corporation',
    website: 'https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist',
    downloadPage: 'https://aka.ms/vs/17/release/vc_redist.x64.exe',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.VCRedist.2015+.x64' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.VCRedist.2015+.x64' } },
    tags: ['runtime', 'cplusplus', 'prerequisite'],
    featured: true
  },
  {
    id: 'dotnet-desktop-runtime-8',
    name: 'Microsoft .NET Desktop Runtime 8.0 (x64)',
    category: 'Runtimes & Dependencies',
    description: 'Runtime needed to run Windows desktop apps (WPF, Windows Forms) built with .NET 8.',
    publisher: 'Microsoft Corporation',
    website: 'https://dotnet.microsoft.com/download/dotnet/8.0',
    downloadPage: 'https://dotnet.microsoft.com/download/dotnet/8.0',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.DotNet.DesktopRuntime.8' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.DotNet.DesktopRuntime.8' } },
    tags: ['dotnet', 'runtime', 'wpf', 'winforms'],
    featured: true
  },
  {
    id: 'edge-webview2-runtime',
    name: 'Microsoft Edge WebView2 Runtime',
    category: 'Runtimes & Dependencies',
    description: 'Chromium-based web rendering engine embedded in Windows desktop applications.',
    publisher: 'Microsoft Corporation',
    website: 'https://developer.microsoft.com/microsoft-edge/webview2/',
    downloadPage: 'https://developer.microsoft.com/microsoft-edge/webview2/#download-section',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.EdgeWebView2Runtime' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.EdgeWebView2Runtime' } },
    tags: ['webview2', 'chromium', 'runtime']
  },
  {
    id: 'directx-runtime',
    name: 'DirectX End-User Runtimes',
    category: 'Runtimes & Dependencies',
    description: 'Legacy DirectX libraries required by classic 3D games and multimedia applications.',
    publisher: 'Microsoft Corporation',
    website: 'https://www.microsoft.com/download/details.aspx?id=35',
    downloadPage: 'https://www.microsoft.com/download/details.aspx?id=35',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['x64', 'x86'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.DirectX' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.DirectX' } },
    tags: ['directx', 'gaming', 'legacy', 'graphics']
  },
  {
    id: 'vcredist-2015-2022-arm64',
    name: 'Microsoft Visual C++ 2015-2022 Redistributable (ARM64)',
    category: 'Runtimes & Dependencies',
    description: 'ARM64 runtime components for C++ applications on Windows on ARM devices.',
    publisher: 'Microsoft Corporation',
    website: 'https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist',
    downloadPage: 'https://aka.ms/vs/17/release/vc_redist.arm64.exe',
    license: 'Freeware',
    requiresAdmin: true,
    supportedOS: ['windows'],
    architectures: ['arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.VCRedist.2015+.arm64' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.VCRedist.2015+.arm64' } },
    tags: ['arm64', 'cplusplus', 'runtime']
  },
  {
    id: 'dotnet-runtime-8',
    name: 'Microsoft .NET Runtime 8.0 (Console / Server)',
    category: 'Runtimes & Dependencies',
    description: 'Base runtime to run console and server applications built with .NET 8.',
    publisher: 'Microsoft Corporation',
    website: 'https://dotnet.microsoft.com/download/dotnet/8.0',
    downloadPage: 'https://dotnet.microsoft.com/download/dotnet/8.0',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'Microsoft.DotNet.Runtime.8' }
    },
    detection: { windows: { type: 'winget', checkValue: 'Microsoft.DotNet.Runtime.8' } },
    tags: ['dotnet', 'runtime', 'cli']
  },
  {
    id: 'temurin-17-jdk',
    name: 'Eclipse Temurin JDK 17 (LTS)',
    category: 'Runtimes & Dependencies',
    description: 'Long-term support release of OpenJDK 17 for legacy and enterprise Java workloads.',
    publisher: 'Eclipse Foundation',
    website: 'https://adoptium.net/',
    downloadPage: 'https://adoptium.net/temurin/releases/?version=17',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64', 'arm64'],
    packages: {
      windows: { manager: 'winget', packageId: 'EclipseAdoptium.Temurin.17.JDK' }
    },
    detection: { windows: { type: 'winget', checkValue: 'EclipseAdoptium.Temurin.17.JDK' } },
    tags: ['java', 'jdk17', 'jvm']
  },
  {
    id: 'temurin-8-jre',
    name: 'Eclipse Temurin JRE 8 (Legacy)',
    category: 'Runtimes & Dependencies',
    description: 'Java 8 runtime environment maintained for older industrial and desktop applications.',
    publisher: 'Eclipse Foundation',
    website: 'https://adoptium.net/',
    downloadPage: 'https://adoptium.net/temurin/releases/?version=8',
    license: 'Open Source',
    requiresAdmin: true,
    supportedOS: ['windows', 'macos', 'linux'],
    architectures: ['x64'],
    packages: {
      windows: { manager: 'winget', packageId: 'EclipseAdoptium.Temurin.8.JRE' }
    },
    detection: { windows: { type: 'winget', checkValue: 'EclipseAdoptium.Temurin.8.JRE' } },
    tags: ['java8', 'jre', 'legacy']
  }
];

// Check duplicates and required fields
const ids = new Set();
for (const app of allApps) {
  if (ids.has(app.id)) {
    console.error('DUPLICATE ID:', app.id);
    process.exit(1);
  }
  ids.add(app.id);
  if (!app.name || !app.category || !app.description || !app.publisher || !app.supportedOS || !app.architectures) {
    console.error('MISSING REQUIRED FIELDS on app:', app.id);
    process.exit(1);
  }
}

const catalogData = {
  version: '2.0.0',
  lastUpdated: new Date().toISOString(),
  categories: categories,
  totalApps: allApps.length,
  apps: allApps
};

const outputPath = path.resolve(__dirname, '../src/data/catalog.json');
fs.writeFileSync(outputPath, JSON.stringify(catalogData, null, 2), 'utf-8');

console.log(`Successfully generated verified catalog with ${allApps.length} applications across ${categories.length} categories.`);
